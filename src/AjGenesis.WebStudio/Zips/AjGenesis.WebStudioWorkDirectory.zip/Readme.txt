This is the working directory of AjGenesis.WebStudio

You can change the directory used editing the web.config file:

  <appSettings>
    <add key="AjGenesisDirectory" value="../AjGenesis.WebStudioWorkDirectory"/>
  </appSettings>

located in AjGenesis.WebStudio directory

If the directory path begins with a "." (a dot) then it is relative to the web site directory.

