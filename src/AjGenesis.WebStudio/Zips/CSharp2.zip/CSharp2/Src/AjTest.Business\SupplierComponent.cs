
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Supplier
 *		Supplier
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class SupplierComponent : SupplierComponentBase {

		public override void Validate(Supplier entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Supplier entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Supplier entity) {
			base.ValidateDelete(entity);
		}
	}
}

