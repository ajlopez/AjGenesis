
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class EmployeeSkillData {

		public void Insert(EmployeeSkill entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("EmployeeSkillInsert", CommandType.StoredProcedure, 
				dpid,
				entity.IdEmployee, 
				entity.IdSkill 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(EmployeeSkill entity) {
			DataService.ExecuteNonQuery("EmployeeSkillUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.IdEmployee, 
				entity.IdSkill 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("EmployeeSkillDelete", CommandType.StoredProcedure, id);
		}

		public EmployeeSkill GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("EmployeeSkillGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				EmployeeSkill entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<EmployeeSkill> GetAll() {
			IDataReader reader = null;
			List<EmployeeSkill> list = new List<EmployeeSkill>();

			reader = DataService.ExecuteReader("EmployeeSkillGetAll", CommandType.StoredProcedure );
			EmployeeSkill entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("EmployeeSkillGetAll", CommandType.StoredProcedure );
		}
		public DataSet GetAllEx() {
			return DataService.ExecuteDataSet("EmployeeSkillGetAllEx", CommandType.StoredProcedure );
		}


		public List<EmployeeSkill> GetByEmployee(int IdEmployee) {
			IDataReader reader = null;
			List<EmployeeSkill> list = new List<EmployeeSkill>();

			reader = DataService.ExecuteReader("EmployeeSkillGetByEmployee", CommandType.StoredProcedure, IdEmployee);

			EmployeeSkill entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByEmployeeEx(int IdEmployee) {
			return DataService.ExecuteDataSet("EmployeeSkillGetByEmployeeEx", CommandType.StoredProcedure, IdEmployee);
		}

		public List<EmployeeSkill> GetBySkill(int IdSkill) {
			IDataReader reader = null;
			List<EmployeeSkill> list = new List<EmployeeSkill>();

			reader = DataService.ExecuteReader("EmployeeSkillGetBySkill", CommandType.StoredProcedure, IdSkill);

			EmployeeSkill entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetBySkillEx(int IdSkill) {
			return DataService.ExecuteDataSet("EmployeeSkillGetBySkillEx", CommandType.StoredProcedure, IdSkill);
		}

		private EmployeeSkill Make(IDataReader reader) {
			EmployeeSkill entity = new EmployeeSkill();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["IdEmployee"] == System.DBNull.Value)
				entity.IdEmployee = 0;
			else
				entity.IdEmployee = (int) reader["IdEmployee"];
			if (reader["IdSkill"] == System.DBNull.Value)
				entity.IdSkill = 0;
			else
				entity.IdSkill = (int) reader["IdSkill"];

			return entity;
		}
	}
}

