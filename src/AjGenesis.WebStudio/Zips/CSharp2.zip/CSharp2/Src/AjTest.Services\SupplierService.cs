
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Supplier
 *		Supplier
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Business;

using AjFramework.Data;

namespace AjTest.Services {
	public class SupplierService {
		private static SupplierComponent component = new SupplierComponent();

		public static void Insert(Supplier entity) {
			component.Insert(entity);
		}

		public static void Update(Supplier entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static Supplier GetById(int id) {
			return component.GetById(id);
		}

		public static List<Supplier> GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}
	}
}


