
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Employee
 *		Employee
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Business;

using AjFramework.Data;

namespace AjTest.Services {
	public class EmployeeService {
		private static EmployeeComponent component = new EmployeeComponent();

		public static void Insert(Employee entity) {
			component.Insert(entity);
		}

		public static void Update(Employee entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static Employee GetById(int id) {
			return component.GetById(id);
		}

		public static List<Employee> GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}

		public static DataSet GetAllEx() {
			return component.GetAllEx();
		}

		public static List<Employee> GetByDepartment(int IdDepartment) {
			return component.GetByDepartment(IdDepartment);
		}

		public static DataSet GetByDepartmentEx(int IdDepartment) {
			return component.GetByDepartmentEx(IdDepartment);
		}
	}
}


