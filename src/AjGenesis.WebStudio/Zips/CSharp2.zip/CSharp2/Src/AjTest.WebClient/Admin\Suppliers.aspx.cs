
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using AjTest.Services;
using AjTest.Entities;

public partial class Admin_SuppliersPage : System.Web.UI.Page
{
	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
       if (!IsPostBack) {
           gvwData.DataSource = SupplierService.GetList();
           gvwData.DataBind();
		}
	}
}

