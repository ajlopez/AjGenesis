
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using AjTest.Services;
using AjTest.Entities;

public partial class Admin_TaskUpdatePage : System.Web.UI.Page
{
	public Task Entity;

	public int IdEntity {
		get {
			return (int) ViewState["IdEntity"];
		}
		set {
			ViewState["IdEntity"] = value;
		}
	}

		public DataView Employees;
		public DataView Projects;


	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack) {
			if (Request["Id"]==null) {
				IdEntity = 0;
				Entity = new Task();
			}
			else {
				IdEntity = Convert.ToInt32(Request["Id"]);
				Entity = TaskService.GetById(IdEntity);
			}
			Employees = GetEmployees();
			Projects = GetProjects();
           	DataBind();

			if (IdEntity>0) {
				ddlEmployees.SelectedValue = Entity.IdEmployee.ToString();
				ddlProjects.SelectedValue = Entity.IdProject.ToString();
			}
			else {
				if (Request["IdEmployee"]!=null)
					ddlEmployees.SelectedValue = Request["IdEmployee"];
				if (Request["IdProject"]!=null)
					ddlProjects.SelectedValue = Request["IdProject"];
			}
		}
	}

	private bool FormValidate() {
		return true;
	}

	private DataView GetEmployees() {
		DataSet ds;

		ds = EmployeeService.GetList();

      DataRow dr;

      dr = ds.Tables[0].NewRow();
      dr["Id"] = 0;
      dr["EmployeeCode"] = "";
      ds.Tables[0].Rows.Add(dr);

		DataView dw = new DataView(ds.Tables[0]);
   	dw.Sort = "EmployeeCode";

		return dw;
	}

	private DataView GetProjects() {
		DataSet ds;

		ds = ProjectService.GetList();

      DataRow dr;

      dr = ds.Tables[0].NewRow();
      dr["Id"] = 0;
      dr["Description"] = "";
      ds.Tables[0].Rows.Add(dr);

		DataView dw = new DataView(ds.Tables[0]);
   	dw.Sort = "Description";

		return dw;
	}


	private void Update() {
		if (IdEntity>0)
			Entity = TaskService.GetById(IdEntity);
		else
			Entity = new Task();

        
		Entity.Description = txtDescription.Text;
      Entity.IdEmployee = Convert.ToInt32(ddlEmployees.SelectedValue);
      Entity.IdProject = Convert.ToInt32(ddlProjects.SelectedValue);
        

     	if (IdEntity == 0)
			TaskService.Insert(Entity);
		else
			TaskService.Update(Entity);
	}

   protected void btnAccept_Click(object sender,EventArgs e) {
		if (!IsValid)
			return;

		try {
			if (FormValidate()) {
				Update();
				if (IdEntity==0)
	            Server.Transfer("Tasks.aspx");
				else
					Server.Transfer("Task.aspx?Id=" + IdEntity);
			}
		}
      catch (Exception ex) {
         lblMensaje.Visible = true;
         lblMensaje.Text = ex.Message;
		}
	}
}

