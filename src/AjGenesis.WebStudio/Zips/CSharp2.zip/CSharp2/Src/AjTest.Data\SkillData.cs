
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Skill
 *		Skill
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class SkillData {

		public void Insert(Skill entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("SkillInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Skill entity) {
			DataService.ExecuteNonQuery("SkillUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("SkillDelete", CommandType.StoredProcedure, id);
		}

		public Skill GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("SkillGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Skill entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Skill> GetAll() {
			IDataReader reader = null;
			List<Skill> list = new List<Skill>();

			reader = DataService.ExecuteReader("SkillGetAll", CommandType.StoredProcedure );
			Skill entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("SkillGetAll", CommandType.StoredProcedure );
		}

		private Skill Make(IDataReader reader) {
			Skill entity = new Skill();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];

			return entity;
		}
	}
}

