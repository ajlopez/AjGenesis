
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Skill
 *		Skill
 *	
 */

using System;

namespace AjTest.Entities {

	public class Skill {

//	Private Fields

		private int id;
		private string description;

//	Default Constructor

		public Skill() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Description
		{
			get {
				return description;
			}
			set {
				description = value;
			}
		}


	}

}
