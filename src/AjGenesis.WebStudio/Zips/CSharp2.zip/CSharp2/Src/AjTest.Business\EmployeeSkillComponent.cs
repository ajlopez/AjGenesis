
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class EmployeeSkillComponent : EmployeeSkillComponentBase {

		public override void Validate(EmployeeSkill entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(EmployeeSkill entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(EmployeeSkill entity) {
			base.ValidateDelete(entity);
		}
	}
}

