
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

using System;

namespace AjTest.Entities {

	public class EmployeeSkill {

//	Private Fields

		private int id;
		private int idEmployee;
		private int idSkill;

//	Default Constructor

		public EmployeeSkill() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public int IdEmployee
		{
			get {
				return idEmployee;
			}
			set {
				idEmployee = value;
			}
		}

	
		public int IdSkill
		{
			get {
				return idSkill;
			}
			set {
				idSkill = value;
			}
		}


	}

}
