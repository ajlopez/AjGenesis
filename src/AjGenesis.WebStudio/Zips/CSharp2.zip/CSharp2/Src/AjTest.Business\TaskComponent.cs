
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Task
 *		Task
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class TaskComponent : TaskComponentBase {

		public override void Validate(Task entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Task entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Task entity) {
			base.ValidateDelete(entity);
		}
	}
}

