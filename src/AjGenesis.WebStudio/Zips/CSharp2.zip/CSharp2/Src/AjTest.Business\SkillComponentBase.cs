
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Skill
 *		Skill
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {

	public class SkillComponentBase {
		protected static SkillData data = new SkillData();

		public virtual void Validate(Skill entity) {
			if (entity.Description == null || entity.Description.ToString() == "")
				throw new Exception("Description required");
		}

		public virtual void ValidateNew(Skill entity) {
			if (entity.Description == null || entity.Description.ToString() == "")
				throw new Exception("Description required");
		}

		public virtual void ValidateDelete(Skill entity) {
		}

		public void Insert(Skill entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Skill entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Skill GetById(int id) {
			return data.GetById(id);
		}

		public List<Skill> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


