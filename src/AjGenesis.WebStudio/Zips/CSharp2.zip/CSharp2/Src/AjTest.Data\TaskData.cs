
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Task
 *		Task
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class TaskData {

		public void Insert(Task entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("TaskInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description, 
				entity.IdEmployee, 
				entity.IdProject 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Task entity) {
			DataService.ExecuteNonQuery("TaskUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description, 
				entity.IdEmployee, 
				entity.IdProject 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("TaskDelete", CommandType.StoredProcedure, id);
		}

		public Task GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("TaskGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Task entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Task> GetAll() {
			IDataReader reader = null;
			List<Task> list = new List<Task>();

			reader = DataService.ExecuteReader("TaskGetAll", CommandType.StoredProcedure );
			Task entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("TaskGetAll", CommandType.StoredProcedure );
		}
		public DataSet GetAllEx() {
			return DataService.ExecuteDataSet("TaskGetAllEx", CommandType.StoredProcedure );
		}


		public List<Task> GetByEmployee(int IdEmployee) {
			IDataReader reader = null;
			List<Task> list = new List<Task>();

			reader = DataService.ExecuteReader("TaskGetByEmployee", CommandType.StoredProcedure, IdEmployee);

			Task entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByEmployeeEx(int IdEmployee) {
			return DataService.ExecuteDataSet("TaskGetByEmployeeEx", CommandType.StoredProcedure, IdEmployee);
		}

		public List<Task> GetByProject(int IdProject) {
			IDataReader reader = null;
			List<Task> list = new List<Task>();

			reader = DataService.ExecuteReader("TaskGetByProject", CommandType.StoredProcedure, IdProject);

			Task entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByProjectEx(int IdProject) {
			return DataService.ExecuteDataSet("TaskGetByProjectEx", CommandType.StoredProcedure, IdProject);
		}

		private Task Make(IDataReader reader) {
			Task entity = new Task();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];
			if (reader["IdEmployee"] == System.DBNull.Value)
				entity.IdEmployee = 0;
			else
				entity.IdEmployee = (int) reader["IdEmployee"];
			if (reader["IdProject"] == System.DBNull.Value)
				entity.IdProject = 0;
			else
				entity.IdProject = (int) reader["IdProject"];

			return entity;
		}
	}
}

