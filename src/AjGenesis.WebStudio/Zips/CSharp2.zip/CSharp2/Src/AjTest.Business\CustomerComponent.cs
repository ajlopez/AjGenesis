
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Customer
 *		Customer
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class CustomerComponent : CustomerComponentBase {

		public override void Validate(Customer entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Customer entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Customer entity) {
			base.ValidateDelete(entity);
		}
	}
}

