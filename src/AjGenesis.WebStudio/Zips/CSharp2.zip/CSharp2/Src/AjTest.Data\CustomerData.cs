
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Customer
 *		Customer
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class CustomerData {

		public void Insert(Customer entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("CustomerInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Name, 
				entity.Address 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Customer entity) {
			DataService.ExecuteNonQuery("CustomerUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Name, 
				entity.Address 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("CustomerDelete", CommandType.StoredProcedure, id);
		}

		public Customer GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("CustomerGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Customer entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Customer> GetAll() {
			IDataReader reader = null;
			List<Customer> list = new List<Customer>();

			reader = DataService.ExecuteReader("CustomerGetAll", CommandType.StoredProcedure );
			Customer entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("CustomerGetAll", CommandType.StoredProcedure );
		}

		private Customer Make(IDataReader reader) {
			Customer entity = new Customer();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Name"] == System.DBNull.Value)
				entity.Name = null;
			else
				entity.Name = (string) reader["Name"];
			if (reader["Address"] == System.DBNull.Value)
				entity.Address = null;
			else
				entity.Address = (string) reader["Address"];

			return entity;
		}
	}
}

