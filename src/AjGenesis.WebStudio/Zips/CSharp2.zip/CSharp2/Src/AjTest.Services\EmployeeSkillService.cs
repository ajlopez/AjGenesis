
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Business;

using AjFramework.Data;

namespace AjTest.Services {
	public class EmployeeSkillService {
		private static EmployeeSkillComponent component = new EmployeeSkillComponent();

		public static void Insert(EmployeeSkill entity) {
			component.Insert(entity);
		}

		public static void Update(EmployeeSkill entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static EmployeeSkill GetById(int id) {
			return component.GetById(id);
		}

		public static List<EmployeeSkill> GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}

		public static DataSet GetAllEx() {
			return component.GetAllEx();
		}

		public static List<EmployeeSkill> GetByEmployee(int IdEmployee) {
			return component.GetByEmployee(IdEmployee);
		}

		public static DataSet GetByEmployeeEx(int IdEmployee) {
			return component.GetByEmployeeEx(IdEmployee);
		}

		public static List<EmployeeSkill> GetBySkill(int IdSkill) {
			return component.GetBySkill(IdSkill);
		}

		public static DataSet GetBySkillEx(int IdSkill) {
			return component.GetBySkillEx(IdSkill);
		}
	}
}


