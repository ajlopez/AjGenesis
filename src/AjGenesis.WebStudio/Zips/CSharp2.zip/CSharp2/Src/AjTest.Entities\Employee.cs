
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Employee
 *		Employee
 *	
 */

using System;

namespace AjTest.Entities {

	public class Employee {

//	Private Fields

		private int id;
		private string employeeCode;
		private string lastName;
		private string firstName;
		private int idDepartment;

//	Default Constructor

		public Employee() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string EmployeeCode
		{
			get {
				return employeeCode;
			}
			set {
				employeeCode = value;
			}
		}

	
		public string LastName
		{
			get {
				return lastName;
			}
			set {
				lastName = value;
			}
		}

	
		public string FirstName
		{
			get {
				return firstName;
			}
			set {
				firstName = value;
			}
		}

	
		public int IdDepartment
		{
			get {
				return idDepartment;
			}
			set {
				idDepartment = value;
			}
		}


	}

}
