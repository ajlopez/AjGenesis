
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Department
 *		Department
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class DepartmentData {

		public void Insert(Department entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("DepartmentInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Department entity) {
			DataService.ExecuteNonQuery("DepartmentUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("DepartmentDelete", CommandType.StoredProcedure, id);
		}

		public Department GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("DepartmentGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Department entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Department> GetAll() {
			IDataReader reader = null;
			List<Department> list = new List<Department>();

			reader = DataService.ExecuteReader("DepartmentGetAll", CommandType.StoredProcedure );
			Department entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("DepartmentGetAll", CommandType.StoredProcedure );
		}

		private Department Make(IDataReader reader) {
			Department entity = new Department();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];

			return entity;
		}
	}
}

