
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	News
 *		News Entity
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Business;

using AjFramework.Data;

namespace AjPortal.Services {
	public class NewsService {
		private static NewsComponent component = new NewsComponent();

		public static void Insert(News entity) {
			component.Insert(entity);
		}

		public static void Update(News entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static News GetById(int id) {
			return component.GetById(id);
		}

		public static IList GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}

		public static DataSet GetAllEx() {
			return component.GetAllEx();
		}

		public static void IList GetByNewsCategory(int IdCategory) {
			return component.GetByNewsCategory(IdCategory);
		}

		public static DataSet GetByNewsCategoryEx(int IdCategory) {
			return component.GetByNewsCategoryEx(IdCategory);
		}
	}
}


