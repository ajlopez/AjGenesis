
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	ProductCategory
 *		Product Category
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {

	public class ProductCategoryComponentBase {
		protected static ProductCategoryData data = new ProductCategoryData();

		public virtual void Validate(ProductCategory entity) {
		}

		public virtual void ValidateNew(ProductCategory entity) {
		}

		public virtual void ValidateDelete(ProductCategory entity) {
		}

		public void Insert(ProductCategory entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(ProductCategory entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public ProductCategory GetById(int id) {
			return data.GetById(id);
		}

		public IList GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


