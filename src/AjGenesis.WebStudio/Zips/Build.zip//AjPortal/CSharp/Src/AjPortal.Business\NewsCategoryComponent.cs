
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	NewsCategory
 *		News Category
 *	
 */

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {
	public class NewsCategoryComponent : NewsCategoryComponentBase {

		public override void Validate(NewsCategory entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(NewsCategory entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(NewsCategory entity) {
			base.ValidateDelete(entity);
		}
	}
}

