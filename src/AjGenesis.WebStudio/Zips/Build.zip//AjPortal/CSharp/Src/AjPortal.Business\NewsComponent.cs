
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	News
 *		News Entity
 *	
 */

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {
	public class NewsComponent : NewsComponentBase {

		public override void Validate(News entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(News entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(News entity) {
			base.ValidateDelete(entity);
		}
	}
}

