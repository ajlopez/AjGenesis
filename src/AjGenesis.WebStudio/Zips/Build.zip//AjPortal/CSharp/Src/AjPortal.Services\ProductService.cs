
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	Product
 *		Product Entity
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Business;

using AjFramework.Data;

namespace AjPortal.Services {
	public class ProductService {
		private static ProductComponent component = new ProductComponent();

		public static void Insert(Product entity) {
			component.Insert(entity);
		}

		public static void Update(Product entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static Product GetById(int id) {
			return component.GetById(id);
		}

		public static IList GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}

		public static DataSet GetAllEx() {
			return component.GetAllEx();
		}

		public static void IList GetByProductCategory(int IdCategory) {
			return component.GetByProductCategory(IdCategory);
		}

		public static DataSet GetByProductCategoryEx(int IdCategory) {
			return component.GetByProductCategoryEx(IdCategory);
		}
	}
}


