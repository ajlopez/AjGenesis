
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	NewsCategory
 *		News Category
 *	
 */

namespace AjPortal.Entities {

	public class NewsCategory {

//	Private Fields

		private int id;
		private string description;

//	Default Constructor

		public NewsCategory() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Description
		{
			get {
				return description;
			}
			set {
				description = value;
			}
		}


	}

}
