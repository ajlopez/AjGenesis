
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	Product
 *		Product Entity
 *	
 */

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {
	public class ProductComponent : ProductComponentBase {

		public override void Validate(Product entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Product entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Product entity) {
			base.ValidateDelete(entity);
		}
	}
}

