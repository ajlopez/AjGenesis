
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	Product
 *		Product Entity
 *	
 */

namespace AjPortal.Entities {

	public class Product {

//	Private Fields

		private int id;
		private string description;
		private string detail;
		private int price;
		private int idCategory;
		private string imageFile;

//	Default Constructor

		public Product() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Description
		{
			get {
				return description;
			}
			set {
				description = value;
			}
		}

	
		public string Detail
		{
			get {
				return detail;
			}
			set {
				detail = value;
			}
		}

	
		public int Price
		{
			get {
				return price;
			}
			set {
				price = value;
			}
		}

	
		public int IdCategory
		{
			get {
				return idCategory;
			}
			set {
				idCategory = value;
			}
		}

	
		public string ImageFile
		{
			get {
				return imageFile;
			}
			set {
				imageFile = value;
			}
		}


	}

}
