
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	NewsCategory
 *		News Category
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {

	public class NewsCategoryComponentBase {
		protected static NewsCategoryData data = new NewsCategoryData();

		public virtual void Validate(NewsCategory entity) {
		}

		public virtual void ValidateNew(NewsCategory entity) {
		}

		public virtual void ValidateDelete(NewsCategory entity) {
		}

		public void Insert(NewsCategory entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(NewsCategory entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public NewsCategory GetById(int id) {
			return data.GetById(id);
		}

		public IList GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


