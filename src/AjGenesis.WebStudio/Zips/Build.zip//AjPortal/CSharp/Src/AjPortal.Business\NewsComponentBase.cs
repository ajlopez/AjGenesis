
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	News
 *		News Entity
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {

	public class NewsComponentBase {
		protected static NewsData data = new NewsData();

		public virtual void Validate(News entity) {
		}

		public virtual void ValidateNew(News entity) {
		}

		public virtual void ValidateDelete(News entity) {
		}

		public void Insert(News entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(News entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public News GetById(int id) {
			return data.GetById(id);
		}

		public IList GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}

		public DataSet GetAllEx() {
			return data.GetAllEx();
		}

		public IList GetByNewsCategory(int IdCategory) {
			return data.GetByNewsCategory(IdCategory);
		}

		public DataSet GetByNewsCategoryEx(int IdCategory) {
			return data.GetByNewsCategoryEx(IdCategory);
		}
	}
}


