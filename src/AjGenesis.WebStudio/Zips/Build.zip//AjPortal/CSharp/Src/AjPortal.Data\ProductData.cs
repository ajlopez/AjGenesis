
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	Product
 *		Product Entity
 *	
 */

using System.Collections;
using System.Data;

using AjFramework.Data;

using AjPortal.Entities;

namespace AjPortal.Data {

	public class ProductData {

		public void Insert(Product entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("ProductInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description, 
				entity.Detail, 
				entity.Price, 
				entity.IdCategory, 
				entity.ImageFile 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Product entity) {
			DataService.ExecuteNonQuery("ProductUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description, 
				entity.Detail, 
				entity.Price, 
				entity.IdCategory, 
				entity.ImageFile 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("ProductDelete", CommandType.StoredProcedure, id);
		}

		public Product GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("ProductGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Product entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public IList GetAll() {
			IDataReader reader = null;
			ArrayList list = new ArrayList();

			reader = DataService.ExecuteReader("ProductGetAll", CommandType.StoredProcedure );
			Product entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("ProductGetAll", CommandType.StoredProcedure );
		}
		public DataSet GetAllEx() {
			return DataService.ExecuteDataSet("ProductGetAllEx", CommandType.StoredProcedure );
		}


		public IList GetByProductCategory(int IdCategory) {
			IDataReader reader = null;
			ArrayList list = new ArrayList();

			reader = DataService.ExecuteReader("ProductGetByProductCategory", CommandType.StoredProcedure, IdCategory);

			Product entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByProductCategoryEx(int IdCategory) {
			return DataService.ExecuteDataSet("ProductGetByProductCategoryEx", CommandType.StoredProcedure, IdCategory);
		}

		private Product Make(IDataReader reader) {
			Product entity = new Product();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];
			if (reader["Detail"] == System.DBNull.Value)
				entity.Detail = null;
			else
				entity.Detail = (string) reader["Detail"];
			if (reader["Price"] == System.DBNull.Value)
				entity.Price = 0;
			else
				entity.Price = (int) reader["Price"];
			if (reader["IdCategory"] == System.DBNull.Value)
				entity.IdCategory = 0;
			else
				entity.IdCategory = (int) reader["IdCategory"];
			if (reader["ImageFile"] == System.DBNull.Value)
				entity.ImageFile = null;
			else
				entity.ImageFile = (string) reader["ImageFile"];

			return entity;
		}
	}
}

