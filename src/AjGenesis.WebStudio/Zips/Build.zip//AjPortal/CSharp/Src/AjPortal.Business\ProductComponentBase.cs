
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	Product
 *		Product Entity
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {

	public class ProductComponentBase {
		protected static ProductData data = new ProductData();

		public virtual void Validate(Product entity) {
		}

		public virtual void ValidateNew(Product entity) {
		}

		public virtual void ValidateDelete(Product entity) {
		}

		public void Insert(Product entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Product entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Product GetById(int id) {
			return data.GetById(id);
		}

		public IList GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}

		public DataSet GetAllEx() {
			return data.GetAllEx();
		}

		public IList GetByProductCategory(int IdCategory) {
			return data.GetByProductCategory(IdCategory);
		}

		public DataSet GetByProductCategoryEx(int IdCategory) {
			return data.GetByProductCategoryEx(IdCategory);
		}
	}
}


