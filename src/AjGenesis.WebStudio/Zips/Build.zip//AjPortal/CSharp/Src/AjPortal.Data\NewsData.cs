
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	News
 *		News Entity
 *	
 */

using System.Collections;
using System.Data;

using AjFramework.Data;

using AjPortal.Entities;

namespace AjPortal.Data {

	public class NewsData {

		public void Insert(News entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("NewsInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Title, 
				entity.Abstract, 
				entity.Content, 
				entity.ImageFile, 
				entity.IdCategory 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(News entity) {
			DataService.ExecuteNonQuery("NewsUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Title, 
				entity.Abstract, 
				entity.Content, 
				entity.ImageFile, 
				entity.IdCategory 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("NewsDelete", CommandType.StoredProcedure, id);
		}

		public News GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("NewsGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				News entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public IList GetAll() {
			IDataReader reader = null;
			ArrayList list = new ArrayList();

			reader = DataService.ExecuteReader("NewsGetAll", CommandType.StoredProcedure );
			News entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("NewsGetAll", CommandType.StoredProcedure );
		}
		public DataSet GetAllEx() {
			return DataService.ExecuteDataSet("NewsGetAllEx", CommandType.StoredProcedure );
		}


		public IList GetByNewsCategory(int IdCategory) {
			IDataReader reader = null;
			ArrayList list = new ArrayList();

			reader = DataService.ExecuteReader("NewsGetByNewsCategory", CommandType.StoredProcedure, IdCategory);

			News entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByNewsCategoryEx(int IdCategory) {
			return DataService.ExecuteDataSet("NewsGetByNewsCategoryEx", CommandType.StoredProcedure, IdCategory);
		}

		private News Make(IDataReader reader) {
			News entity = new News();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Title"] == System.DBNull.Value)
				entity.Title = null;
			else
				entity.Title = (string) reader["Title"];
			if (reader["Abstract"] == System.DBNull.Value)
				entity.Abstract = null;
			else
				entity.Abstract = (string) reader["Abstract"];
			if (reader["Content"] == System.DBNull.Value)
				entity.Content = null;
			else
				entity.Content = (string) reader["Content"];
			if (reader["ImageFile"] == System.DBNull.Value)
				entity.ImageFile = null;
			else
				entity.ImageFile = (string) reader["ImageFile"];
			if (reader["IdCategory"] == System.DBNull.Value)
				entity.IdCategory = 0;
			else
				entity.IdCategory = (int) reader["IdCategory"];

			return entity;
		}
	}
}

