
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	ProductCategory
 *		Product Category
 *	
 */

using AjPortal.Entities;
using AjPortal.Data;

namespace AjPortal.Business {
	public class ProductCategoryComponent : ProductCategoryComponentBase {

		public override void Validate(ProductCategory entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(ProductCategory entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(ProductCategory entity) {
			base.ValidateDelete(entity);
		}
	}
}

