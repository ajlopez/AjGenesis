
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	NewsCategory
 *		News Category
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Business;

using AjFramework.Data;

namespace AjPortal.Services {
	public class NewsCategoryService {
		private static NewsCategoryComponent component = new NewsCategoryComponent();

		public static void Insert(NewsCategory entity) {
			component.Insert(entity);
		}

		public static void Update(NewsCategory entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static NewsCategory GetById(int id) {
			return component.GetById(id);
		}

		public static IList GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}
	}
}


