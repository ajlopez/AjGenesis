
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	ProductCategory
 *		Product Category
 *	
 */

using System;
using System.Data;
using System.Collections;

using AjPortal.Entities;
using AjPortal.Business;

using AjFramework.Data;

namespace AjPortal.Services {
	public class ProductCategoryService {
		private static ProductCategoryComponent component = new ProductCategoryComponent();

		public static void Insert(ProductCategory entity) {
			component.Insert(entity);
		}

		public static void Update(ProductCategory entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static ProductCategory GetById(int id) {
			return component.GetById(id);
		}

		public static IList GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}
	}
}


