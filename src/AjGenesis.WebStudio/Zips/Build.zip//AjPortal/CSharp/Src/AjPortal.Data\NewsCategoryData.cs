
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	NewsCategory
 *		News Category
 *	
 */

using System.Collections;
using System.Data;

using AjFramework.Data;

using AjPortal.Entities;

namespace AjPortal.Data {

	public class NewsCategoryData {

		public void Insert(NewsCategory entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("NewsCategoryInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(NewsCategory entity) {
			DataService.ExecuteNonQuery("NewsCategoryUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("NewsCategoryDelete", CommandType.StoredProcedure, id);
		}

		public NewsCategory GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("NewsCategoryGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				NewsCategory entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public IList GetAll() {
			IDataReader reader = null;
			ArrayList list = new ArrayList();

			reader = DataService.ExecuteReader("NewsCategoryGetAll", CommandType.StoredProcedure );
			NewsCategory entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("NewsCategoryGetAll", CommandType.StoredProcedure );
		}

		private NewsCategory Make(IDataReader reader) {
			NewsCategory entity = new NewsCategory();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];

			return entity;
		}
	}
}

