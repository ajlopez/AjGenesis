
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	News
 *		News Entity
 *	
 */

namespace AjPortal.Entities {

	public class News {

//	Private Fields

		private int id;
		private string title;
		private string abstract;
		private string content;
		private string imageFile;
		private int idCategory;

//	Default Constructor

		public News() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Title
		{
			get {
				return title;
			}
			set {
				title = value;
			}
		}

	
		public string Abstract
		{
			get {
				return abstract;
			}
			set {
				abstract = value;
			}
		}

	
		public string Content
		{
			get {
				return content;
			}
			set {
				content = value;
			}
		}

	
		public string ImageFile
		{
			get {
				return imageFile;
			}
			set {
				imageFile = value;
			}
		}

	
		public int IdCategory
		{
			get {
				return idCategory;
			}
			set {
				idCategory = value;
			}
		}


	}

}
