
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	ProductCategory
 *		Product Category
 *	
 */

using System.Collections;
using System.Data;

using AjFramework.Data;

using AjPortal.Entities;

namespace AjPortal.Data {

	public class ProductCategoryData {

		public void Insert(ProductCategory entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("ProductCategoryInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(ProductCategory entity) {
			DataService.ExecuteNonQuery("ProductCategoryUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("ProductCategoryDelete", CommandType.StoredProcedure, id);
		}

		public ProductCategory GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("ProductCategoryGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				ProductCategory entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public IList GetAll() {
			IDataReader reader = null;
			ArrayList list = new ArrayList();

			reader = DataService.ExecuteReader("ProductCategoryGetAll", CommandType.StoredProcedure );
			ProductCategory entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("ProductCategoryGetAll", CommandType.StoredProcedure );
		}

		private ProductCategory Make(IDataReader reader) {
			ProductCategory entity = new ProductCategory();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];

			return entity;
		}
	}
}

