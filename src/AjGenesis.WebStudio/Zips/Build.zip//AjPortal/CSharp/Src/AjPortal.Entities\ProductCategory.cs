
/*
 *	Project AjPortal
 *		AjPortal using AjGenesis
 *	Entity	ProductCategory
 *		Product Category
 *	
 */

namespace AjPortal.Entities {

	public class ProductCategory {

//	Private Fields

		private int id;
		private string description;

//	Default Constructor

		public ProductCategory() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Description
		{
			get {
				return description;
			}
			set {
				description = value;
			}
		}


	}

}
