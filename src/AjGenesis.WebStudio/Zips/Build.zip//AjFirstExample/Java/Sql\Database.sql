
--
--		Project:		AjFirstExample
--		Description:	First Example using AjGenesis
--



--
--		Entity:		Customer
--		Description:	Customer Entity
--


drop table if exists customers;


create table customers (
		Id int NOT NULL auto_increment,
	
		Name varchar(200),
	
		Address text,
	
		Notes text,
		primary key (Id)
);


--
--		Entity:		Supplier
--		Description:	Supplier Entity
--


drop table if exists suppliers;


create table suppliers (
		Id int NOT NULL auto_increment,
	
		Name varchar(200),
	
		Address text,
	
		Notes text,
		primary key (Id)
);

