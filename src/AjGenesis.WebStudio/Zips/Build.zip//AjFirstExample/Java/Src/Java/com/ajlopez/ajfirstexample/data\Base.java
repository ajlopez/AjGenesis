
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Data Access Object	SupplierDAO
 *		Supplier Entity
 *	
 */

package com.ajlopez.ajfirstexample.data;

import java.sql.*;

public class Base {
    private Connection connection;
    
    static {
        try {
            Class.forName(getDriverName()).newInstance();        
        }
        catch (Exception e) {}
    }
    
    static String getDriverName() {
        return "com.mysql.jdbc.Driver";
    }
    
    static String getURL() {
        return "jdbc:mysql://localhost/ajfirstexample?user=root&password=";
    }
    
    public Connection getConnection() throws Exception {
        if (connection!=null)
            return connection;
        
        try {
            connection = DriverManager.getConnection(getURL());
            return connection;
        }
        catch (SQLException e) {
            throw e;
        }
    }
    
    public void dispose() throws Exception {
        if (connection==null)
            return;
        
        try {
            connection.close();
            connection=null;
        }
        catch (SQLException e) {
            throw e;
        }
    }
}

