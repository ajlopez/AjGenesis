
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Services	CustomerServices
 *		Customer Entity
 *	
 */

package com.ajlopez.ajfirstexample.services;

import java.util.List;

import com.ajlopez.ajfirstexample.model.*;
import com.ajlopez.ajfirstexample.data.*;

public class CustomerServices {
    public static Customer getById(int id) throws Exception {
        Base base = new Base();
        CustomerDAO dao = new CustomerDAO(base);
        Customer entity = dao.getById(id);
        base.dispose();
        
        return entity;
    }
    
    public static List getAll() throws Exception {
        Base base = new Base();
        CustomerDAO dao = new CustomerDAO(base);
        List entities = dao.getAll();
        base.dispose();
        
        return entities;
    }

    public static void insert(Customer entity) throws Exception {
        Base base = new Base();
        CustomerDAO dao = new CustomerDAO(base);
        dao.insert(entity);
        base.dispose();
    }

    public static void update(Customer entity) throws Exception {
        Base base = new Base();
        CustomerDAO dao = new CustomerDAO(base);
        dao.update(entity);
        base.dispose();
    }

    public static void delete(Customer entity) throws Exception {
        Base base = new Base();
        CustomerDAO dao = new CustomerDAO(base);
        dao.delete(entity);
        base.dispose();
    }
}

