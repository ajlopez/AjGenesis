
/*
 *	Project	AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 */

package com.ajlopez.ajfirstexample.data;

import java.util.*;
import java.sql.*;

import com.ajlopez.ajfirstexample.model.*;

public class SupplierDAO {
	private Base base;

	public SupplierDAO(Base base) {
		this.base = base;
	}

	public Supplier getById(int id) throws Exception {
		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("select Id, Name, Address, Notes from suppliers where Id = ?");

		stmt.setInt(1,id);

		ResultSet rs = stmt.executeQuery();

		Supplier supplier;

		if (rs.next())
			supplier = make(rs);
		else
			supplier = null;

		rs.close();
		stmt.close();
		con.close();

		return supplier;
	}

	public List getAll() throws Exception {
		List list = new ArrayList();

		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("select Id, Name, Address, Notes from suppliers order by Id");

		ResultSet rs = stmt.executeQuery();

		while (rs.next())
			list.add(make(rs));

		rs.close();
		stmt.close();
		con.close();

		return list;
	}

	public void insert(Supplier supplier) throws Exception {
		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("insert into suppliers(Name, Address, Notes) values(?, ?, ?)");

		stmt.setString(1,supplier.getName());
		stmt.setString(2,supplier.getAddress());
		stmt.setString(3,supplier.getNotes());

		stmt.executeUpdate();

		stmt.close();
		con.close();
	}

	public void update(Supplier supplier) throws Exception {
		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("update suppliers set Name = ?, Address = ?, Notes = ? where Id = ?");

		stmt.setString(1,supplier.getName());
		stmt.setString(2,supplier.getAddress());
		stmt.setString(3,supplier.getNotes());
		stmt.setInt(4,supplier.getId());

		stmt.executeUpdate();

		stmt.close();
		con.close();
	}

	public void delete(Supplier supplier) throws Exception {
	}

	private Supplier make(ResultSet rs) throws Exception {
		Supplier supplier = new Supplier();

		supplier.setId(rs.getInt("Id"));
		supplier.setName(rs.getString("Name"));
		supplier.setAddress(rs.getString("Address"));
		supplier.setNotes(rs.getString("Notes"));

		return supplier;
	}
}

