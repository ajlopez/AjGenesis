
/*
 *	Project	AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

package com.ajlopez.ajfirstexample.data;

import java.util.*;
import java.sql.*;

import com.ajlopez.ajfirstexample.model.*;

public class CustomerDAO {
	private Base base;

	public CustomerDAO(Base base) {
		this.base = base;
	}

	public Customer getById(int id) throws Exception {
		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("select Id, Name, Address, Notes from customers where Id = ?");

		stmt.setInt(1,id);

		ResultSet rs = stmt.executeQuery();

		Customer customer;

		if (rs.next())
			customer = make(rs);
		else
			customer = null;

		rs.close();
		stmt.close();
		con.close();

		return customer;
	}

	public List getAll() throws Exception {
		List list = new ArrayList();

		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("select Id, Name, Address, Notes from customers order by Id");

		ResultSet rs = stmt.executeQuery();

		while (rs.next())
			list.add(make(rs));

		rs.close();
		stmt.close();
		con.close();

		return list;
	}

	public void insert(Customer customer) throws Exception {
		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("insert into customers(Name, Address, Notes) values(?, ?, ?)");

		stmt.setString(1,customer.getName());
		stmt.setString(2,customer.getAddress());
		stmt.setString(3,customer.getNotes());

		stmt.executeUpdate();

		stmt.close();
		con.close();
	}

	public void update(Customer customer) throws Exception {
		Connection con = base.getConnection();

		PreparedStatement stmt = con.prepareStatement("update customers set Name = ?, Address = ?, Notes = ? where Id = ?");

		stmt.setString(1,customer.getName());
		stmt.setString(2,customer.getAddress());
		stmt.setString(3,customer.getNotes());
		stmt.setInt(4,customer.getId());

		stmt.executeUpdate();

		stmt.close();
		con.close();
	}

	public void delete(Customer customer) throws Exception {
	}

	private Customer make(ResultSet rs) throws Exception {
		Customer customer = new Customer();

		customer.setId(rs.getInt("Id"));
		customer.setName(rs.getString("Name"));
		customer.setAddress(rs.getString("Address"));
		customer.setNotes(rs.getString("Notes"));

		return customer;
	}
}

