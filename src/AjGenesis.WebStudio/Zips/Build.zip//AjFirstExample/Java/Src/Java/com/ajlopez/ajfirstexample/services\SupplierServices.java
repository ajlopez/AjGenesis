
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Services	SupplierServices
 *		Supplier Entity
 *	
 */

package com.ajlopez.ajfirstexample.services;

import java.util.List;

import com.ajlopez.ajfirstexample.model.*;
import com.ajlopez.ajfirstexample.data.*;

public class SupplierServices {
    public static Supplier getById(int id) throws Exception {
        Base base = new Base();
        SupplierDAO dao = new SupplierDAO(base);
        Supplier entity = dao.getById(id);
        base.dispose();
        
        return entity;
    }
    
    public static List getAll() throws Exception {
        Base base = new Base();
        SupplierDAO dao = new SupplierDAO(base);
        List entities = dao.getAll();
        base.dispose();
        
        return entities;
    }

    public static void insert(Supplier entity) throws Exception {
        Base base = new Base();
        SupplierDAO dao = new SupplierDAO(base);
        dao.insert(entity);
        base.dispose();
    }

    public static void update(Supplier entity) throws Exception {
        Base base = new Base();
        SupplierDAO dao = new SupplierDAO(base);
        dao.update(entity);
        base.dispose();
    }

    public static void delete(Supplier entity) throws Exception {
        Base base = new Base();
        SupplierDAO dao = new SupplierDAO(base);
        dao.delete(entity);
        base.dispose();
    }
}

