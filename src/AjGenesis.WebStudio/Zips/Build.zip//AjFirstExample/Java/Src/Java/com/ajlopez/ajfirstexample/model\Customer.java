
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

package com.ajlopez.ajfirstexample.model;

public class Customer {

//	Private Fields

	private int id;
	private String name;
	private String address;
	private String notes;

//	Default Constructor

	public Customer() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String value) {
		name = value;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String value) {
		address = value;
	}
	
	public String getNotes() {
		return notes;
	}

	public void setNotes(String value) {
		notes = value;
	}

}

