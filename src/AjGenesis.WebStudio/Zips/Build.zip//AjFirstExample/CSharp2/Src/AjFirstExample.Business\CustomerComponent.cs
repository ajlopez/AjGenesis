
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

using AjFirstExample.Entities;
using AjFirstExample.Data;

namespace AjFirstExample.Business {
	public class CustomerComponent : CustomerComponentBase {

		public override void Validate(Customer entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Customer entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Customer entity) {
			base.ValidateDelete(entity);
		}
	}
}

