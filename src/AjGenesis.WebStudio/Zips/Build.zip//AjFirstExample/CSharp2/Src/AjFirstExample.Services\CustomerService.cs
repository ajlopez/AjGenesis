
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjFirstExample.Entities;
using AjFirstExample.Business;

using AjFramework.Data;

namespace AjFirstExample.Services {
	public class CustomerService {
		private static CustomerComponent component = new CustomerComponent();

		public static void Insert(Customer entity) {
			component.Insert(entity);
		}

		public static void Update(Customer entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static Customer GetById(int id) {
			return component.GetById(id);
		}

		public static List<Customer> GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}
	}
}


