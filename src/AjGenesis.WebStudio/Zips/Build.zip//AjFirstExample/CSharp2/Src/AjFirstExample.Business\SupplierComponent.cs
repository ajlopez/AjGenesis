
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 */

using AjFirstExample.Entities;
using AjFirstExample.Data;

namespace AjFirstExample.Business {
	public class SupplierComponent : SupplierComponentBase {

		public override void Validate(Supplier entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Supplier entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Supplier entity) {
			base.ValidateDelete(entity);
		}
	}
}

