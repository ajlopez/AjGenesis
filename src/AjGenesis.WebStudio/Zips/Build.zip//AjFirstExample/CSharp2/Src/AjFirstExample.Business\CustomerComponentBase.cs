
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjFirstExample.Entities;
using AjFirstExample.Data;

namespace AjFirstExample.Business {

	public class CustomerComponentBase {
		protected static CustomerData data = new CustomerData();

		public virtual void Validate(Customer entity) {
		}

		public virtual void ValidateNew(Customer entity) {
		}

		public virtual void ValidateDelete(Customer entity) {
		}

		public void Insert(Customer entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Customer entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Customer GetById(int id) {
			return data.GetById(id);
		}

		public List<Customer> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


