
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Task
 *		Task
 *	
 */

using System;

namespace AjTest.Entities {

	public class Task {

//	Private Fields

		private int id;
		private string description;
		private int idEmployee;
		private int idProject;

//	Default Constructor

		public Task() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Description
		{
			get {
				return description;
			}
			set {
				description = value;
			}
		}

	
		public int IdEmployee
		{
			get {
				return idEmployee;
			}
			set {
				idEmployee = value;
			}
		}

	
		public int IdProject
		{
			get {
				return idProject;
			}
			set {
				idProject = value;
			}
		}


	}

}
