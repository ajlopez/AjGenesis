
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Supplier
 *		Supplier
 *	
 */

using System;

namespace AjTest.Entities {

	public class Supplier {

//	Private Fields

		private int id;
		private string name;
		private string address;

//	Default Constructor

		public Supplier() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Name
		{
			get {
				return name;
			}
			set {
				name = value;
			}
		}

	
		public string Address
		{
			get {
				return address;
			}
			set {
				address = value;
			}
		}


	}

}
