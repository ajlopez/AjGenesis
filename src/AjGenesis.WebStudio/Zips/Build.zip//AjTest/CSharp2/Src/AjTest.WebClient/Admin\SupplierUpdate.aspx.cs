
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using AjTest.Services;
using AjTest.Entities;

public partial class Admin_SupplierUpdatePage : System.Web.UI.Page
{
	public Supplier Entity;

	public int IdEntity {
		get {
			return (int) ViewState["IdEntity"];
		}
		set {
			ViewState["IdEntity"] = value;
		}
	}



	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack) {
			if (Request["Id"]==null) {
				IdEntity = 0;
				Entity = new Supplier();
			}
			else {
				IdEntity = Convert.ToInt32(Request["Id"]);
				Entity = SupplierService.GetById(IdEntity);
			}
           	DataBind();

			if (IdEntity>0) {
			}
			else {
			}
		}
	}

	private bool FormValidate() {
		return true;
	}


	private void Update() {
		if (IdEntity>0)
			Entity = SupplierService.GetById(IdEntity);
		else
			Entity = new Supplier();

        
		Entity.Name = txtName.Text;
        
		Entity.Address = txtAddress.Text;
        

     	if (IdEntity == 0)
			SupplierService.Insert(Entity);
		else
			SupplierService.Update(Entity);
	}

   protected void btnAccept_Click(object sender,EventArgs e) {
		if (!IsValid)
			return;

		try {
			if (FormValidate()) {
				Update();
				if (IdEntity==0)
	            Server.Transfer("Suppliers.aspx");
				else
					Server.Transfer("Supplier.aspx?Id=" + IdEntity);
			}
		}
      catch (Exception ex) {
         lblMensaje.Visible = true;
         lblMensaje.Text = ex.Message;
		}
	}
}

