
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Employee
 *		Employee
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class EmployeeComponent : EmployeeComponentBase {

		public override void Validate(Employee entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Employee entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Employee entity) {
			base.ValidateDelete(entity);
		}
	}
}

