
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {

	public class EmployeeSkillComponentBase {
		protected static EmployeeSkillData data = new EmployeeSkillData();

		public virtual void Validate(EmployeeSkill entity) {
		}

		public virtual void ValidateNew(EmployeeSkill entity) {
		}

		public virtual void ValidateDelete(EmployeeSkill entity) {
		}

		public void Insert(EmployeeSkill entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(EmployeeSkill entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public EmployeeSkill GetById(int id) {
			return data.GetById(id);
		}

		public List<EmployeeSkill> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}

		public DataSet GetAllEx() {
			return data.GetAllEx();
		}

		public List<EmployeeSkill> GetByEmployee(int IdEmployee) {
			return data.GetByEmployee(IdEmployee);
		}

		public DataSet GetByEmployeeEx(int IdEmployee) {
			return data.GetByEmployeeEx(IdEmployee);
		}

		public List<EmployeeSkill> GetBySkill(int IdSkill) {
			return data.GetBySkill(IdSkill);
		}

		public DataSet GetBySkillEx(int IdSkill) {
			return data.GetBySkillEx(IdSkill);
		}
	}
}


