
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Project
 *		Project
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class ProjectComponent : ProjectComponentBase {

		public override void Validate(Project entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Project entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Project entity) {
			base.ValidateDelete(entity);
		}
	}
}

