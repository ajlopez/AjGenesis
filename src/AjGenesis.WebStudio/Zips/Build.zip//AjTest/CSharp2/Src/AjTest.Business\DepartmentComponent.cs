
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Department
 *		Department
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class DepartmentComponent : DepartmentComponentBase {

		public override void Validate(Department entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Department entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Department entity) {
			base.ValidateDelete(entity);
		}
	}
}

