
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Project
 *		Project
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {

	public class ProjectComponentBase {
		protected static ProjectData data = new ProjectData();

		public virtual void Validate(Project entity) {
			if (entity.Description == null || entity.Description.ToString() == "")
				throw new Exception("Description required");
		}

		public virtual void ValidateNew(Project entity) {
			if (entity.Description == null || entity.Description.ToString() == "")
				throw new Exception("Description required");
		}

		public virtual void ValidateDelete(Project entity) {
		}

		public void Insert(Project entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Project entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Project GetById(int id) {
			return data.GetById(id);
		}

		public List<Project> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


