
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Employee
 *		Employee
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class EmployeeData {

		public void Insert(Employee entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("EmployeeInsert", CommandType.StoredProcedure, 
				dpid,
				entity.EmployeeCode, 
				entity.LastName, 
				entity.FirstName, 
				entity.IdDepartment 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Employee entity) {
			DataService.ExecuteNonQuery("EmployeeUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.EmployeeCode, 
				entity.LastName, 
				entity.FirstName, 
				entity.IdDepartment 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("EmployeeDelete", CommandType.StoredProcedure, id);
		}

		public Employee GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("EmployeeGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Employee entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Employee> GetAll() {
			IDataReader reader = null;
			List<Employee> list = new List<Employee>();

			reader = DataService.ExecuteReader("EmployeeGetAll", CommandType.StoredProcedure );
			Employee entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("EmployeeGetAll", CommandType.StoredProcedure );
		}
		public DataSet GetAllEx() {
			return DataService.ExecuteDataSet("EmployeeGetAllEx", CommandType.StoredProcedure );
		}


		public List<Employee> GetByDepartment(int IdDepartment) {
			IDataReader reader = null;
			List<Employee> list = new List<Employee>();

			reader = DataService.ExecuteReader("EmployeeGetByDepartment", CommandType.StoredProcedure, IdDepartment);

			Employee entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByDepartmentEx(int IdDepartment) {
			return DataService.ExecuteDataSet("EmployeeGetByDepartmentEx", CommandType.StoredProcedure, IdDepartment);
		}

		private Employee Make(IDataReader reader) {
			Employee entity = new Employee();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["EmployeeCode"] == System.DBNull.Value)
				entity.EmployeeCode = null;
			else
				entity.EmployeeCode = (string) reader["EmployeeCode"];
			if (reader["LastName"] == System.DBNull.Value)
				entity.LastName = null;
			else
				entity.LastName = (string) reader["LastName"];
			if (reader["FirstName"] == System.DBNull.Value)
				entity.FirstName = null;
			else
				entity.FirstName = (string) reader["FirstName"];
			if (reader["IdDepartment"] == System.DBNull.Value)
				entity.IdDepartment = 0;
			else
				entity.IdDepartment = (int) reader["IdDepartment"];

			return entity;
		}
	}
}

