
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Project
 *		Project
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjTest.Entities;

namespace AjTest.Data {

	public class ProjectData {

		public void Insert(Project entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("ProjectInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Description 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Project entity) {
			DataService.ExecuteNonQuery("ProjectUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Description 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("ProjectDelete", CommandType.StoredProcedure, id);
		}

		public Project GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("ProjectGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Project entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Project> GetAll() {
			IDataReader reader = null;
			List<Project> list = new List<Project>();

			reader = DataService.ExecuteReader("ProjectGetAll", CommandType.StoredProcedure );
			Project entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("ProjectGetAll", CommandType.StoredProcedure );
		}

		private Project Make(IDataReader reader) {
			Project entity = new Project();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Description"] == System.DBNull.Value)
				entity.Description = null;
			else
				entity.Description = (string) reader["Description"];

			return entity;
		}
	}
}

