
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Customer
 *		Customer
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {

	public class CustomerComponentBase {
		protected static CustomerData data = new CustomerData();

		public virtual void Validate(Customer entity) {
			if (entity.Name == null || entity.Name.ToString() == "")
				throw new Exception("Name required");
		}

		public virtual void ValidateNew(Customer entity) {
			if (entity.Name == null || entity.Name.ToString() == "")
				throw new Exception("Name required");
		}

		public virtual void ValidateDelete(Customer entity) {
		}

		public void Insert(Customer entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Customer entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Customer GetById(int id) {
			return data.GetById(id);
		}

		public List<Customer> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


