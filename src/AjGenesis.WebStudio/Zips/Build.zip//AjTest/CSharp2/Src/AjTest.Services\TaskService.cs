
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Task
 *		Task
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Business;

using AjFramework.Data;

namespace AjTest.Services {
	public class TaskService {
		private static TaskComponent component = new TaskComponent();

		public static void Insert(Task entity) {
			component.Insert(entity);
		}

		public static void Update(Task entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static Task GetById(int id) {
			return component.GetById(id);
		}

		public static List<Task> GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}

		public static DataSet GetAllEx() {
			return component.GetAllEx();
		}

		public static List<Task> GetByEmployee(int IdEmployee) {
			return component.GetByEmployee(IdEmployee);
		}

		public static DataSet GetByEmployeeEx(int IdEmployee) {
			return component.GetByEmployeeEx(IdEmployee);
		}

		public static List<Task> GetByProject(int IdProject) {
			return component.GetByProject(IdProject);
		}

		public static DataSet GetByProjectEx(int IdProject) {
			return component.GetByProjectEx(IdProject);
		}
	}
}


