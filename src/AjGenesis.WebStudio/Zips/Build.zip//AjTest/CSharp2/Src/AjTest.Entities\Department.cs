
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Department
 *		Department
 *	
 */

using System;

namespace AjTest.Entities {

	public class Department {

//	Private Fields

		private int id;
		private string description;

//	Default Constructor

		public Department() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Description
		{
			get {
				return description;
			}
			set {
				description = value;
			}
		}


	}

}
