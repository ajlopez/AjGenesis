
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Project
 *		Project
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Business;

using AjFramework.Data;

namespace AjTest.Services {
	public class ProjectService {
		private static ProjectComponent component = new ProjectComponent();

		public static void Insert(Project entity) {
			component.Insert(entity);
		}

		public static void Update(Project entity) {
			component.Update(entity);
		}

		public static void Delete(int id) {
			component.Delete(id);
		}

		public static Project GetById(int id) {
			return component.GetById(id);
		}

		public static List<Project> GetAll() {
			return component.GetAll();
		}

		public static DataSet GetList() {
			return component.GetAllAsDs();
		}
	}
}


