
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Skill
 *		Skill
 *	
 */

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {
	public class SkillComponent : SkillComponentBase {

		public override void Validate(Skill entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Skill entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Skill entity) {
			base.ValidateDelete(entity);
		}
	}
}

