
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Department
 *		Department
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {

	public class DepartmentComponentBase {
		protected static DepartmentData data = new DepartmentData();

		public virtual void Validate(Department entity) {
			if (entity.Description == null || entity.Description.ToString() == "")
				throw new Exception("Description required");
		}

		public virtual void ValidateNew(Department entity) {
			if (entity.Description == null || entity.Description.ToString() == "")
				throw new Exception("Description required");
		}

		public virtual void ValidateDelete(Department entity) {
		}

		public void Insert(Department entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Department entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Department GetById(int id) {
			return data.GetById(id);
		}

		public List<Department> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


