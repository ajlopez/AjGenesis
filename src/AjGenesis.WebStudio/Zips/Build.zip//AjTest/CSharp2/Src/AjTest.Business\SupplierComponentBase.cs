
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjTest
 *		AjTest
 *	Entity	Supplier
 *		Supplier
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjTest.Entities;
using AjTest.Data;

namespace AjTest.Business {

	public class SupplierComponentBase {
		protected static SupplierData data = new SupplierData();

		public virtual void Validate(Supplier entity) {
			if (entity.Name == null || entity.Name.ToString() == "")
				throw new Exception("Name required");
		}

		public virtual void ValidateNew(Supplier entity) {
			if (entity.Name == null || entity.Name.ToString() == "")
				throw new Exception("Name required");
		}

		public virtual void ValidateDelete(Supplier entity) {
		}

		public void Insert(Supplier entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Supplier entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Supplier GetById(int id) {
			return data.GetById(id);
		}

		public List<Supplier> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


