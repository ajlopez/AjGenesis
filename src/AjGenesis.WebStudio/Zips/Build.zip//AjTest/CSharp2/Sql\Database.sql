
--
--		Project:		AjTest
--		Description:	AjTest
--

use master

declare @dttm varchar(55)
select  @dttm=convert(varchar,getdate(),113)
raiserror('Beginning Create AjTest.SQL at %s ....',1,1,@dttm) with nowait

GO

if exists (select * from sysdatabases where name='AjTest')
begin
  raiserror('Dropping existing AjTest database ....',0,1)
  DROP database AjTest
end
GO

CHECKPOINT
go

raiserror('Creating AjTest database....',0,1)
go

/*
   Use default size with autogrow
*/

create database AjTest
go

checkpoint

go

use AjTest

go

if db_name() <> 'AjTest'
   raiserror('Error in AjTest.SQL, ''USE AjTest'' failed!  Killing the SPID now.'
            ,22,127) with log

go

use AjTest
go
set ansi_nulls on
go
set quoted_identifier on
go


--
--		Entity:		Employee
--		Description:	Employee
--


if exists (select name from sysobjects 
         where name = 'employees' and type = 'U')
	drop table employees
go

create table employees (
		[Id] [int] identity (1, 1) primary key not null,	
		[EmployeeCode] varchar(20),	
		[LastName] varchar(100),	
		[FirstName] varchar(100),	
		[IdDepartment] int null
)
go


if exists (select name from sysobjects 
         where name = 'EmployeeInsert' and type = 'P')
	drop procedure dbo.EmployeeInsert
go

create procedure dbo.EmployeeInsert
	(
		@Id int output,	
		@EmployeeCode varchar(20),	
		@LastName varchar(100),	
		@FirstName varchar(100),	
		@IdDepartment int
	)
as
		if @IdDepartment <= 0
		begin
			set @IdDepartment = null
		end
	Insert into employees(	
		[EmployeeCode],	
		[LastName],	
		[FirstName],	
		[IdDepartment]
		)
	values (	
		@EmployeeCode,	
		@LastName,	
		@FirstName,	
		@IdDepartment		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'EmployeeUpdate' and type = 'P')
	drop procedure dbo.EmployeeUpdate
go

create procedure dbo.EmployeeUpdate
	(
	
		@Id int,	
		@EmployeeCode varchar(20),	
		@LastName varchar(100),	
		@FirstName varchar(100),	
		@IdDepartment int
	)
as
		if @IdDepartment <= 0
		begin
			set @IdDepartment = null
		end
	Update employees
		set 	
			[EmployeeCode] = @EmployeeCode,	
			[LastName] = @LastName,	
			[FirstName] = @FirstName,	
			[IdDepartment] = @IdDepartment
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'EmployeeDelete' and type = 'P')
	drop procedure dbo.EmployeeDelete
go

create procedure dbo.EmployeeDelete
	(
		@Id int
	)
as
	Delete employees
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'EmployeeGetById' and type = 'P')
	drop procedure dbo.EmployeeGetById
go

create procedure dbo.EmployeeGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[EmployeeCode],	
		[LastName],	
		[FirstName],	
		[IdDepartment]
	from employees
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'EmployeeGetAll' and type = 'P')
	drop procedure dbo.EmployeeGetAll
go

create procedure dbo.EmployeeGetAll
as
	select 	
		[Id],	
		[EmployeeCode],	
		[LastName],	
		[FirstName],	
		[IdDepartment]
	from employees
	order by Id
go


/*		Public Relations */

if exists (select name from sysobjects 
         where name = 'EmployeeGetByDepartment' and type = 'P')
	drop procedure dbo.EmployeeGetByDepartment
go

create procedure dbo.EmployeeGetByDepartment
	(
		@IdDepartment  int
	)
as
	select [Id], [EmployeeCode], [LastName], [FirstName], [IdDepartment]
	from employees
	where [IdDepartment] = @IdDepartment
	order by Id
go


--
--		Entity:		Department
--		Description:	Department
--


if exists (select name from sysobjects 
         where name = 'departments' and type = 'U')
	drop table departments
go

create table departments (
		[Id] [int] identity (1, 1) primary key not null,	
		[Description] varchar(200)
)
go


if exists (select name from sysobjects 
         where name = 'DepartmentInsert' and type = 'P')
	drop procedure dbo.DepartmentInsert
go

create procedure dbo.DepartmentInsert
	(
		@Id int output,	
		@Description varchar(200)
	)
as
	Insert into departments(	
		[Description]
		)
	values (	
		@Description		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'DepartmentUpdate' and type = 'P')
	drop procedure dbo.DepartmentUpdate
go

create procedure dbo.DepartmentUpdate
	(
	
		@Id int,	
		@Description varchar(200)
	)
as
	Update departments
		set 	
			[Description] = @Description
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'DepartmentDelete' and type = 'P')
	drop procedure dbo.DepartmentDelete
go

create procedure dbo.DepartmentDelete
	(
		@Id int
	)
as
	Delete departments
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'DepartmentGetById' and type = 'P')
	drop procedure dbo.DepartmentGetById
go

create procedure dbo.DepartmentGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Description]
	from departments
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'DepartmentGetAll' and type = 'P')
	drop procedure dbo.DepartmentGetAll
go

create procedure dbo.DepartmentGetAll
as
	select 	
		[Id],	
		[Description]
	from departments
	order by Id
go


/*		Public Relations */


--
--		Entity:		Supplier
--		Description:	Supplier
--


if exists (select name from sysobjects 
         where name = 'suppliers' and type = 'U')
	drop table suppliers
go

create table suppliers (
		[Id] [int] identity (1, 1) primary key not null,	
		[Name] varchar(200),	
		[Address] varchar(200)
)
go


if exists (select name from sysobjects 
         where name = 'SupplierInsert' and type = 'P')
	drop procedure dbo.SupplierInsert
go

create procedure dbo.SupplierInsert
	(
		@Id int output,	
		@Name varchar(200),	
		@Address varchar(200)
	)
as
	Insert into suppliers(	
		[Name],	
		[Address]
		)
	values (	
		@Name,	
		@Address		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'SupplierUpdate' and type = 'P')
	drop procedure dbo.SupplierUpdate
go

create procedure dbo.SupplierUpdate
	(
	
		@Id int,	
		@Name varchar(200),	
		@Address varchar(200)
	)
as
	Update suppliers
		set 	
			[Name] = @Name,	
			[Address] = @Address
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SupplierDelete' and type = 'P')
	drop procedure dbo.SupplierDelete
go

create procedure dbo.SupplierDelete
	(
		@Id int
	)
as
	Delete suppliers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SupplierGetById' and type = 'P')
	drop procedure dbo.SupplierGetById
go

create procedure dbo.SupplierGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Name],	
		[Address]
	from suppliers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SupplierGetAll' and type = 'P')
	drop procedure dbo.SupplierGetAll
go

create procedure dbo.SupplierGetAll
as
	select 	
		[Id],	
		[Name],	
		[Address]
	from suppliers
	order by Id
go


--
--		Entity:		Customer
--		Description:	Customer
--


if exists (select name from sysobjects 
         where name = 'customers' and type = 'U')
	drop table customers
go

create table customers (
		[Id] [int] identity (1, 1) primary key not null,	
		[Name] varchar(200),	
		[Address] varchar(200)
)
go


if exists (select name from sysobjects 
         where name = 'CustomerInsert' and type = 'P')
	drop procedure dbo.CustomerInsert
go

create procedure dbo.CustomerInsert
	(
		@Id int output,	
		@Name varchar(200),	
		@Address varchar(200)
	)
as
	Insert into customers(	
		[Name],	
		[Address]
		)
	values (	
		@Name,	
		@Address		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'CustomerUpdate' and type = 'P')
	drop procedure dbo.CustomerUpdate
go

create procedure dbo.CustomerUpdate
	(
	
		@Id int,	
		@Name varchar(200),	
		@Address varchar(200)
	)
as
	Update customers
		set 	
			[Name] = @Name,	
			[Address] = @Address
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'CustomerDelete' and type = 'P')
	drop procedure dbo.CustomerDelete
go

create procedure dbo.CustomerDelete
	(
		@Id int
	)
as
	Delete customers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'CustomerGetById' and type = 'P')
	drop procedure dbo.CustomerGetById
go

create procedure dbo.CustomerGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Name],	
		[Address]
	from customers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'CustomerGetAll' and type = 'P')
	drop procedure dbo.CustomerGetAll
go

create procedure dbo.CustomerGetAll
as
	select 	
		[Id],	
		[Name],	
		[Address]
	from customers
	order by Id
go


--
--		Entity:		Project
--		Description:	Project
--


if exists (select name from sysobjects 
         where name = 'projects' and type = 'U')
	drop table projects
go

create table projects (
		[Id] [int] identity (1, 1) primary key not null,	
		[Description] varchar(200)
)
go


if exists (select name from sysobjects 
         where name = 'ProjectInsert' and type = 'P')
	drop procedure dbo.ProjectInsert
go

create procedure dbo.ProjectInsert
	(
		@Id int output,	
		@Description varchar(200)
	)
as
	Insert into projects(	
		[Description]
		)
	values (	
		@Description		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'ProjectUpdate' and type = 'P')
	drop procedure dbo.ProjectUpdate
go

create procedure dbo.ProjectUpdate
	(
	
		@Id int,	
		@Description varchar(200)
	)
as
	Update projects
		set 	
			[Description] = @Description
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'ProjectDelete' and type = 'P')
	drop procedure dbo.ProjectDelete
go

create procedure dbo.ProjectDelete
	(
		@Id int
	)
as
	Delete projects
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'ProjectGetById' and type = 'P')
	drop procedure dbo.ProjectGetById
go

create procedure dbo.ProjectGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Description]
	from projects
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'ProjectGetAll' and type = 'P')
	drop procedure dbo.ProjectGetAll
go

create procedure dbo.ProjectGetAll
as
	select 	
		[Id],	
		[Description]
	from projects
	order by Id
go


/*		Public Relations */


--
--		Entity:		Task
--		Description:	Task
--


if exists (select name from sysobjects 
         where name = 'tasks' and type = 'U')
	drop table tasks
go

create table tasks (
		[Id] [int] identity (1, 1) primary key not null,	
		[Description] varchar(200),	
		[IdEmployee] int null,	
		[IdProject] int null
)
go


if exists (select name from sysobjects 
         where name = 'TaskInsert' and type = 'P')
	drop procedure dbo.TaskInsert
go

create procedure dbo.TaskInsert
	(
		@Id int output,	
		@Description varchar(200),	
		@IdEmployee int,	
		@IdProject int
	)
as
		if @IdEmployee <= 0
		begin
			set @IdEmployee = null
		end
		if @IdProject <= 0
		begin
			set @IdProject = null
		end
	Insert into tasks(	
		[Description],	
		[IdEmployee],	
		[IdProject]
		)
	values (	
		@Description,	
		@IdEmployee,	
		@IdProject		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'TaskUpdate' and type = 'P')
	drop procedure dbo.TaskUpdate
go

create procedure dbo.TaskUpdate
	(
	
		@Id int,	
		@Description varchar(200),	
		@IdEmployee int,	
		@IdProject int
	)
as
		if @IdEmployee <= 0
		begin
			set @IdEmployee = null
		end
		if @IdProject <= 0
		begin
			set @IdProject = null
		end
	Update tasks
		set 	
			[Description] = @Description,	
			[IdEmployee] = @IdEmployee,	
			[IdProject] = @IdProject
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'TaskDelete' and type = 'P')
	drop procedure dbo.TaskDelete
go

create procedure dbo.TaskDelete
	(
		@Id int
	)
as
	Delete tasks
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'TaskGetById' and type = 'P')
	drop procedure dbo.TaskGetById
go

create procedure dbo.TaskGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Description],	
		[IdEmployee],	
		[IdProject]
	from tasks
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'TaskGetAll' and type = 'P')
	drop procedure dbo.TaskGetAll
go

create procedure dbo.TaskGetAll
as
	select 	
		[Id],	
		[Description],	
		[IdEmployee],	
		[IdProject]
	from tasks
	order by Id
go


/*		Public Relations */

if exists (select name from sysobjects 
         where name = 'TaskGetByEmployee' and type = 'P')
	drop procedure dbo.TaskGetByEmployee
go

create procedure dbo.TaskGetByEmployee
	(
		@IdEmployee  int
	)
as
	select [Id], [Description], [IdEmployee], [IdProject]
	from tasks
	where [IdEmployee] = @IdEmployee
	order by Id
go

if exists (select name from sysobjects 
         where name = 'TaskGetByProject' and type = 'P')
	drop procedure dbo.TaskGetByProject
go

create procedure dbo.TaskGetByProject
	(
		@IdProject  int
	)
as
	select [Id], [Description], [IdEmployee], [IdProject]
	from tasks
	where [IdProject] = @IdProject
	order by Id
go


--
--		Entity:		Skill
--		Description:	Skill
--


if exists (select name from sysobjects 
         where name = 'skills' and type = 'U')
	drop table skills
go

create table skills (
		[Id] [int] identity (1, 1) primary key not null,	
		[Description] varchar(200)
)
go


if exists (select name from sysobjects 
         where name = 'SkillInsert' and type = 'P')
	drop procedure dbo.SkillInsert
go

create procedure dbo.SkillInsert
	(
		@Id int output,	
		@Description varchar(200)
	)
as
	Insert into skills(	
		[Description]
		)
	values (	
		@Description		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'SkillUpdate' and type = 'P')
	drop procedure dbo.SkillUpdate
go

create procedure dbo.SkillUpdate
	(
	
		@Id int,	
		@Description varchar(200)
	)
as
	Update skills
		set 	
			[Description] = @Description
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SkillDelete' and type = 'P')
	drop procedure dbo.SkillDelete
go

create procedure dbo.SkillDelete
	(
		@Id int
	)
as
	Delete skills
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SkillGetById' and type = 'P')
	drop procedure dbo.SkillGetById
go

create procedure dbo.SkillGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Description]
	from skills
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SkillGetAll' and type = 'P')
	drop procedure dbo.SkillGetAll
go

create procedure dbo.SkillGetAll
as
	select 	
		[Id],	
		[Description]
	from skills
	order by Id
go


/*		Public Relations */


--
--		Entity:		EmployeeSkill
--		Description:	EmployeeSkill
--


if exists (select name from sysobjects 
         where name = 'employeeskills' and type = 'U')
	drop table employeeskills
go

create table employeeskills (
		[Id] [int] identity (1, 1) primary key not null,	
		[IdEmployee] int null,	
		[IdSkill] int null
)
go


if exists (select name from sysobjects 
         where name = 'EmployeeSkillInsert' and type = 'P')
	drop procedure dbo.EmployeeSkillInsert
go

create procedure dbo.EmployeeSkillInsert
	(
		@Id int output,	
		@IdEmployee int,	
		@IdSkill int
	)
as
		if @IdEmployee <= 0
		begin
			set @IdEmployee = null
		end
		if @IdSkill <= 0
		begin
			set @IdSkill = null
		end
	Insert into employeeskills(	
		[IdEmployee],	
		[IdSkill]
		)
	values (	
		@IdEmployee,	
		@IdSkill		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'EmployeeSkillUpdate' and type = 'P')
	drop procedure dbo.EmployeeSkillUpdate
go

create procedure dbo.EmployeeSkillUpdate
	(
	
		@Id int,	
		@IdEmployee int,	
		@IdSkill int
	)
as
		if @IdEmployee <= 0
		begin
			set @IdEmployee = null
		end
		if @IdSkill <= 0
		begin
			set @IdSkill = null
		end
	Update employeeskills
		set 	
			[IdEmployee] = @IdEmployee,	
			[IdSkill] = @IdSkill
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'EmployeeSkillDelete' and type = 'P')
	drop procedure dbo.EmployeeSkillDelete
go

create procedure dbo.EmployeeSkillDelete
	(
		@Id int
	)
as
	Delete employeeskills
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetById' and type = 'P')
	drop procedure dbo.EmployeeSkillGetById
go

create procedure dbo.EmployeeSkillGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[IdEmployee],	
		[IdSkill]
	from employeeskills
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetAll' and type = 'P')
	drop procedure dbo.EmployeeSkillGetAll
go

create procedure dbo.EmployeeSkillGetAll
as
	select 	
		[Id],	
		[IdEmployee],	
		[IdSkill]
	from employeeskills
	order by Id
go


/*		Public Relations */

if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetByEmployee' and type = 'P')
	drop procedure dbo.EmployeeSkillGetByEmployee
go

create procedure dbo.EmployeeSkillGetByEmployee
	(
		@IdEmployee  int
	)
as
	select [Id], [IdEmployee], [IdSkill]
	from employeeskills
	where [IdEmployee] = @IdEmployee
	order by Id
go

if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetBySkill' and type = 'P')
	drop procedure dbo.EmployeeSkillGetBySkill
go

create procedure dbo.EmployeeSkillGetBySkill
	(
		@IdSkill  int
	)
as
	select [Id], [IdEmployee], [IdSkill]
	from employeeskills
	where [IdSkill] = @IdSkill
	order by Id
go


alter table dbo.employees add
	constraint [fk_employees_departments] foreign key 
	(
		[IdDepartment]
	) references dbo.departments (
		Id
	) on delete cascade  on update cascade 

GO


alter table dbo.tasks add
	constraint [fk_tasks_employees] foreign key 
	(
		[IdEmployee]
	) references dbo.employees (
		Id
	) on delete cascade  on update cascade 

GO


alter table dbo.tasks add
	constraint [fk_tasks_projects] foreign key 
	(
		[IdProject]
	) references dbo.projects (
		Id
	) on delete cascade  on update cascade 

GO


alter table dbo.employeeskills add
	constraint [fk_employeeskills_employees] foreign key 
	(
		[IdEmployee]
	) references dbo.employees (
		Id
	) on delete cascade  on update cascade 

GO


alter table dbo.employeeskills add
	constraint [fk_employeeskills_skills] foreign key 
	(
		[IdSkill]
	) references dbo.skills (
		Id
	) on delete cascade  on update cascade 

GO



if exists (select name from sysobjects 
         where name = 'EmployeeGetAllEx' and type = 'P')
	drop procedure dbo.EmployeeGetAllEx
go

create procedure dbo.EmployeeGetAllEx
as
	select 	
		e.[Id],	
		e.[EmployeeCode],	
		e.[LastName],	
		e.[FirstName],	
		e.[IdDepartment], e1.[Description] as DepartmentDescription
	from employees e
	left join departments e1 on e.[IdDepartment] = e1.[Id]
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'TaskGetAllEx' and type = 'P')
	drop procedure dbo.TaskGetAllEx
go

create procedure dbo.TaskGetAllEx
as
	select 	
		e.[Id],	
		e.[Description],	
		e.[IdEmployee], e1.[EmployeeCode] as EmployeeDescription,	
		e.[IdProject], e2.[Description] as ProjectDescription
	from tasks e
	left join employees e1 on e.[IdEmployee] = e1.[Id]
	left join projects e2 on e.[IdProject] = e2.[Id]
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetAllEx' and type = 'P')
	drop procedure dbo.EmployeeSkillGetAllEx
go

create procedure dbo.EmployeeSkillGetAllEx
as
	select 	
		e.[Id],	
		e.[IdEmployee], e1.[EmployeeCode] as EmployeeDescription,	
		e.[IdSkill], e2.[Description] as SkillDescription
	from employeeskills e
	left join employees e1 on e.[IdEmployee] = e1.[Id]
	left join skills e2 on e.[IdSkill] = e2.[Id]
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'EmployeeGetByDepartmentEx' and type = 'P')
	drop procedure dbo.EmployeeGetByDepartmentEx
go

create procedure dbo.EmployeeGetByDepartmentEx
	(
		@IdDepartment  int
	)
as
	select 	
		e.[Id],	
		e.[EmployeeCode],	
		e.[LastName],	
		e.[FirstName],	
		e.[IdDepartment], e1.[Description] as DepartmentDescription
	from employees e
	left join departments e1 on e.[IdDepartment] = e1.[Id]
	where e.[IdDepartment] = @IdDepartment
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'TaskGetByEmployeeEx' and type = 'P')
	drop procedure dbo.TaskGetByEmployeeEx
go

create procedure dbo.TaskGetByEmployeeEx
	(
		@IdEmployee  int
	)
as
	select 	
		e.[Id],	
		e.[Description],	
		e.[IdEmployee], e1.[EmployeeCode] as EmployeeDescription,	
		e.[IdProject], e2.[Description] as ProjectDescription
	from tasks e
	left join employees e1 on e.[IdEmployee] = e1.[Id]
	left join projects e2 on e.[IdProject] = e2.[Id]
	where e.[IdEmployee] = @IdEmployee
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'TaskGetByProjectEx' and type = 'P')
	drop procedure dbo.TaskGetByProjectEx
go

create procedure dbo.TaskGetByProjectEx
	(
		@IdProject  int
	)
as
	select 	
		e.[Id],	
		e.[Description],	
		e.[IdEmployee], e1.[EmployeeCode] as EmployeeDescription,	
		e.[IdProject], e2.[Description] as ProjectDescription
	from tasks e
	left join employees e1 on e.[IdEmployee] = e1.[Id]
	left join projects e2 on e.[IdProject] = e2.[Id]
	where e.[IdProject] = @IdProject
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetByEmployeeEx' and type = 'P')
	drop procedure dbo.EmployeeSkillGetByEmployeeEx
go

create procedure dbo.EmployeeSkillGetByEmployeeEx
	(
		@IdEmployee  int
	)
as
	select 	
		e.[Id],	
		e.[IdEmployee], e1.[EmployeeCode] as EmployeeDescription,	
		e.[IdSkill], e2.[Description] as SkillDescription
	from employeeskills e
	left join employees e1 on e.[IdEmployee] = e1.[Id]
	left join skills e2 on e.[IdSkill] = e2.[Id]
	where e.[IdEmployee] = @IdEmployee
	order by e.Id
go



if exists (select name from sysobjects 
         where name = 'EmployeeSkillGetBySkillEx' and type = 'P')
	drop procedure dbo.EmployeeSkillGetBySkillEx
go

create procedure dbo.EmployeeSkillGetBySkillEx
	(
		@IdSkill  int
	)
as
	select 	
		e.[Id],	
		e.[IdEmployee], e1.[EmployeeCode] as EmployeeDescription,	
		e.[IdSkill], e2.[Description] as SkillDescription
	from employeeskills e
	left join employees e1 on e.[IdEmployee] = e1.[Id]
	left join skills e2 on e.[IdSkill] = e2.[Id]
	where e.[IdSkill] = @IdSkill
	order by e.Id
go

