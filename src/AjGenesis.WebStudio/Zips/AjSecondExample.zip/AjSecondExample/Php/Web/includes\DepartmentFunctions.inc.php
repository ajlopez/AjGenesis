<?

/*
 *	Functions
 * for Entity Department
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function DepartmentGetById($Id) {
	global $Cfg;

	$sql = "select Id, Name from $Cfg[SqlPrefix]departments where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function DepartmentGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Name from $Cfg[SqlPrefix]departments";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function DepartmentGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Name from $Cfg[SqlPrefix]departments";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function DepartmentGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function DepartmentInsert($Name) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]departments set
		Name = '$Name'";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function DepartmentUpdate($Id, $Name) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]departments set
		Name = '$Name' where Id = $Id";

	DbExecuteUpdate($sql);
}

function DepartmentDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]departments where Id = $Id";
	DbExecuteUpdate($sql);
}

function DepartmentTranslate($Id) {
	global $DepartmentNames;
	global $Cfg;

	if ($DepartmentNames[$Id])
		return $DepartmentNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]departments",$Id,"Name");

	$DepartmentNames[$Id] = $description;

	return $description;
}


?>
