<?

/*
 *	Functions
 * for Entity Employee
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function EmployeeGetById($Id) {
	global $Cfg;

	$sql = "select Id, Name, IdDepartment, Address, Notes from $Cfg[SqlPrefix]employees where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function EmployeeGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Name, IdDepartment, Address, Notes from $Cfg[SqlPrefix]employees";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function EmployeeGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Name, IdDepartment, Address, Notes from $Cfg[SqlPrefix]employees";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function EmployeeGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function EmployeeInsert($Name, $IdDepartment, $Address, $Notes) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]employees set
		Name = '$Name',
		IdDepartment = $IdDepartment,
		Address = '$Address',
		Notes = '$Notes'";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function EmployeeUpdate($Id, $Name, $IdDepartment, $Address, $Notes) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]employees set
		Name = '$Name',
		IdDepartment = $IdDepartment,
		Address = '$Address',
		Notes = '$Notes' where Id = $Id";

	DbExecuteUpdate($sql);
}

function EmployeeDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]employees where Id = $Id";
	DbExecuteUpdate($sql);
}

function EmployeeTranslate($Id) {
	global $EmployeeNames;
	global $Cfg;

	if ($EmployeeNames[$Id])
		return $EmployeeNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]employees",$Id,"Name");

	$EmployeeNames[$Id] = $description;

	return $description;
}


function EmployeeGetByDepartment($IdDepartment) {
	return EmployeeGetList("IdDepartment = $IdDepartment");
}

?>
