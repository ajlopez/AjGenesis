<?
	$Page->Title = 'Employees';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/EmployeeFunctions.inc.php');
	include_once($Page->Prefix . 'includes/DepartmentFunctions.inc.php');

	SessionPut('EmployeeLink',PageCurrent());

	DbConnect();

	$rs = EmployeeGetListView();

	$titles = array('Id', 'Name', 'Department', 'Address', 'Notes');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeForm.php">New Employee...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"EmployeeView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Name']);
		$ColumnDescription = DepartmentTranslate($reg['IdDepartment']);
		DatumLinkGenerate($ColumnDescription, "DepartmentView.php?Id=".$reg['IdDepartment']);
		DatumGenerate($reg['Address']);
		DatumGenerate($reg['Notes']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
