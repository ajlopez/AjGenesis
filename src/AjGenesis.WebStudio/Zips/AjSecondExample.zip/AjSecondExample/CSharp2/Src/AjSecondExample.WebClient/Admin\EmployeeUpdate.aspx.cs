
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using AjSecondExample.Services;
using AjSecondExample.Entities;

public partial class Admin_EmployeeUpdatePage : System.Web.UI.Page
{
	public Employee Entity;

	public int IdEntity {
		get {
			return (int) ViewState["IdEntity"];
		}
		set {
			ViewState["IdEntity"] = value;
		}
	}

		public DataView Departments;


	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack) {
			if (Request["Id"]==null) {
				IdEntity = 0;
				Entity = new Employee();
			}
			else {
				IdEntity = Convert.ToInt32(Request["Id"]);
				Entity = EmployeeService.GetById(IdEntity);
			}
			Departments = GetDepartments();
           	DataBind();

			if (IdEntity>0) {
				ddlDepartments.SelectedValue = Entity.IdDepartment.ToString();
			}
			else {
				if (Request["IdDepartment"]!=null)
					ddlDepartments.SelectedValue = Request["IdDepartment"];
			}
		}
	}

	private bool FormValidate() {
		return true;
	}

	private DataView GetDepartments() {
		DataSet ds;

		ds = DepartmentService.GetList();

      DataRow dr;

      dr = ds.Tables[0].NewRow();
      dr["Id"] = 0;
      dr["Name"] = "";
      ds.Tables[0].Rows.Add(dr);

		DataView dw = new DataView(ds.Tables[0]);
   	dw.Sort = "Name";

		return dw;
	}


	private void Update() {
		if (IdEntity>0)
			Entity = EmployeeService.GetById(IdEntity);
		else
			Entity = new Employee();

        
		Entity.Name = txtName.Text;
      Entity.IdDepartment = Convert.ToInt32(ddlDepartments.SelectedValue);
        
		Entity.Address = txtAddress.Text;
        
		Entity.Notes = txtNotes.Text;
        

     	if (IdEntity == 0)
			EmployeeService.Insert(Entity);
		else
			EmployeeService.Update(Entity);
	}

   protected void btnAccept_Click(object sender,EventArgs e) {
		if (!IsValid)
			return;

		try {
			if (FormValidate()) {
				Update();
				if (IdEntity==0)
	            Server.Transfer("Employees.aspx");
				else
					Server.Transfer("Employee.aspx?Id=" + IdEntity);
			}
		}
      catch (Exception ex) {
         lblMensaje.Visible = true;
         lblMensaje.Text = ex.Message;
		}
	}
}

