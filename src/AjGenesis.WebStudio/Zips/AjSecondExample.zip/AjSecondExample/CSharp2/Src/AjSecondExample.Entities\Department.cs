
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Department
 *		Department Entity
 *	
 */

using System;

namespace AjSecondExample.Entities {

	public class Department {

//	Private Fields

		private int id;
		private string name;

//	Default Constructor

		public Department() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Name
		{
			get {
				return name;
			}
			set {
				name = value;
			}
		}


	}

}
