
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Employee
 *		Employee Entity
 *	
 */

using AjSecondExample.Entities;
using AjSecondExample.Data;

namespace AjSecondExample.Business {
	public class EmployeeComponent : EmployeeComponentBase {

		public override void Validate(Employee entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Employee entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Employee entity) {
			base.ValidateDelete(entity);
		}
	}
}

