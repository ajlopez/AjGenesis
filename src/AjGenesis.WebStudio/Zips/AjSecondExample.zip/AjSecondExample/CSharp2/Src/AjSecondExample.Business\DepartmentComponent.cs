
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Department
 *		Department Entity
 *	
 */

using AjSecondExample.Entities;
using AjSecondExample.Data;

namespace AjSecondExample.Business {
	public class DepartmentComponent : DepartmentComponentBase {

		public override void Validate(Department entity) {
			base.Validate(entity);
		}

		public override void ValidateNew(Department entity) {
			base.ValidateNew(entity);
		}

		public override void ValidateDelete(Department entity) {
			base.ValidateDelete(entity);
		}
	}
}

