
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Employee
 *		Employee Entity
 *	
 */

using System;

namespace AjSecondExample.Entities {

	public class Employee {

//	Private Fields

		private int id;
		private string name;
		private int idDepartment;
		private string address;
		private string notes;

//	Default Constructor

		public Employee() {
		}

//	Public Properties

	
		public int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public string Name
		{
			get {
				return name;
			}
			set {
				name = value;
			}
		}

	
		public int IdDepartment
		{
			get {
				return idDepartment;
			}
			set {
				idDepartment = value;
			}
		}

	
		public string Address
		{
			get {
				return address;
			}
			set {
				address = value;
			}
		}

	
		public string Notes
		{
			get {
				return notes;
			}
			set {
				notes = value;
			}
		}


	}

}
