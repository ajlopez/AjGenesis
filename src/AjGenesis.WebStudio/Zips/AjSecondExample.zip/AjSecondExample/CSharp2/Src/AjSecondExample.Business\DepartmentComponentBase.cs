
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Department
 *		Department Entity
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjSecondExample.Entities;
using AjSecondExample.Data;

namespace AjSecondExample.Business {

	public class DepartmentComponentBase {
		protected static DepartmentData data = new DepartmentData();

		public virtual void Validate(Department entity) {
		}

		public virtual void ValidateNew(Department entity) {
		}

		public virtual void ValidateDelete(Department entity) {
		}

		public void Insert(Department entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Department entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Department GetById(int id) {
			return data.GetById(id);
		}

		public List<Department> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}
	}
}


