
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Employee
 *		Employee Entity
 *	
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using AjFramework.Data;

using AjSecondExample.Entities;

namespace AjSecondExample.Data {

	public class EmployeeData {

		public void Insert(Employee entity) {
			DataParameter dpid = new DataParameter();
			dpid.Value = entity.Id;

			DataService.ExecuteNonQuery("EmployeeInsert", CommandType.StoredProcedure, 
				dpid,
				entity.Name, 
				entity.IdDepartment, 
				entity.Address, 
				entity.Notes 
			);

			entity.Id = (int) dpid.Value;
		}

		public void Update(Employee entity) {
			DataService.ExecuteNonQuery("EmployeeUpdate", CommandType.StoredProcedure, 
				entity.Id, 
				entity.Name, 
				entity.IdDepartment, 
				entity.Address, 
				entity.Notes 
			);
		}

		public void Delete(int id) {
			DataService.ExecuteNonQuery("EmployeeDelete", CommandType.StoredProcedure, id);
		}

		public Employee GetById(int id) {
			IDataReader reader = null;

			try {
				reader = DataService.ExecuteReader("EmployeeGetById", CommandType.StoredProcedure, id);

				if (!reader.Read())
					return null;
			
				Employee entity;

				entity = Make(reader);

				return entity;
			}
			finally {
				reader.Close();
			}
		}

		public List<Employee> GetAll() {
			IDataReader reader = null;
			List<Employee> list = new List<Employee>();

			reader = DataService.ExecuteReader("EmployeeGetAll", CommandType.StoredProcedure );
			Employee entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetAllAsDs() {
			return DataService.ExecuteDataSet("EmployeeGetAll", CommandType.StoredProcedure );
		}
		public DataSet GetAllEx() {
			return DataService.ExecuteDataSet("EmployeeGetAllEx", CommandType.StoredProcedure );
		}


		public List<Employee> GetByDepartment(int IdDepartment) {
			IDataReader reader = null;
			List<Employee> list = new List<Employee>();

			reader = DataService.ExecuteReader("EmployeeGetByDepartment", CommandType.StoredProcedure, IdDepartment);

			Employee entity;
	
			while (reader.Read()) {
				entity = Make(reader);
				list.Add(entity);
			}
			
			reader.Close();

			return list;
		}

		public DataSet GetByDepartmentEx(int IdDepartment) {
			return DataService.ExecuteDataSet("EmployeeGetByDepartmentEx", CommandType.StoredProcedure, IdDepartment);
		}

		private Employee Make(IDataReader reader) {
			Employee entity = new Employee();


			if (reader["Id"] == System.DBNull.Value)
				entity.Id = 0;
			else
				entity.Id = (int) reader["Id"];
			if (reader["Name"] == System.DBNull.Value)
				entity.Name = null;
			else
				entity.Name = (string) reader["Name"];
			if (reader["IdDepartment"] == System.DBNull.Value)
				entity.IdDepartment = 0;
			else
				entity.IdDepartment = (int) reader["IdDepartment"];
			if (reader["Address"] == System.DBNull.Value)
				entity.Address = null;
			else
				entity.Address = (string) reader["Address"];
			if (reader["Notes"] == System.DBNull.Value)
				entity.Notes = null;
			else
				entity.Notes = (string) reader["Notes"];

			return entity;
		}
	}
}

