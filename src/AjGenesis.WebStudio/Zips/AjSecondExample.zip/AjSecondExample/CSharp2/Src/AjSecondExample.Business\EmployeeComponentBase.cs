
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjSecondExample
 *		Second Example using AjGenesis
 *	Entity	Employee
 *		Employee Entity
 *	
 */

using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;

using AjSecondExample.Entities;
using AjSecondExample.Data;

namespace AjSecondExample.Business {

	public class EmployeeComponentBase {
		protected static EmployeeData data = new EmployeeData();

		public virtual void Validate(Employee entity) {
		}

		public virtual void ValidateNew(Employee entity) {
		}

		public virtual void ValidateDelete(Employee entity) {
		}

		public void Insert(Employee entity) {
			ValidateNew(entity);
			data.Insert(entity);
		}

		public void Update(Employee entity) {
			Validate(entity);
			data.Update(entity);
		}

		public void Delete(int id) {
			ValidateDelete(GetById(id));
			data.Delete(id);
		}

		public Employee GetById(int id) {
			return data.GetById(id);
		}

		public List<Employee> GetAll() {
			return data.GetAll();
		}
	
		public DataSet GetAllAsDs() {
			return data.GetAllAsDs();
		}

		public DataSet GetAllEx() {
			return data.GetAllEx();
		}

		public List<Employee> GetByDepartment(int IdDepartment) {
			return data.GetByDepartment(IdDepartment);
		}

		public DataSet GetByDepartmentEx(int IdDepartment) {
			return data.GetByDepartmentEx(IdDepartment);
		}
	}
}


