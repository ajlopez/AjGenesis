<?
	$Page->Title = 'EmployeeSkill';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/EmployeeSkillFunctions.inc.php');

	DbConnect();
	
	SessionPut('EmployeeSkillLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = EmployeeSkillGetById($Id);
	$IdEmployee = $rs['IdEmployee'];
	$IdSkill = $rs['IdSkill'];

	$TranslationIdEmployee = "<a href='EmployeeView.php?Id=".$IdEmployee. "'>".TranslateDescription("$Cfg[SqlPrefix]employees",$IdEmployee,"EmployeeCode","Id")."</a>";
	$TranslationIdSkill = "<a href='SkillView.php?Id=".$IdSkill. "'>".TranslateDescription("$Cfg[SqlPrefix]skills",$IdSkill,"Description","Id")."</a>";

	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeSkillList.php">EmployeeSkills</a>
&nbsp;
&nbsp;
<a href="EmployeeSkillForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="EmployeeSkillDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Employee",$TranslationIdEmployee);
	FieldStaticGenerate("Skill",$TranslationIdSkill);
?>
</table>


</center>


<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
