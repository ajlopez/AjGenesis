<?
	$Page->Title = 'Employee';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');
	include_once($Page->Prefix.'includes/TaskFunctions.inc.php');
	include_once($Page->Prefix.'includes/EmployeeSkillFunctions.inc.php');
	include_once($Page->Prefix.'includes/ProjectFunctions.inc.php');
	include_once($Page->Prefix.'includes/SkillFunctions.inc.php');

	DbConnect();
	
	SessionPut('EmployeeLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = EmployeeGetById($Id);
	$EmployeeCode = $rs['EmployeeCode'];
	$LastName = $rs['LastName'];
	$FirstName = $rs['FirstName'];
	$IdDepartment = $rs['IdDepartment'];

	$TranslationIdDepartment = "<a href='DepartmentView.php?Id=".$IdDepartment. "'>".TranslateDescription("$Cfg[SqlPrefix]departments",$IdDepartment,"Description","Id")."</a>";

	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeList.php">Employees</a>
&nbsp;
&nbsp;
<a href="EmployeeForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="EmployeeDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Code",$EmployeeCode);
	FieldStaticGenerate("Last Name",$LastName);
	FieldStaticGenerate("First Name",$FirstName);
	FieldStaticGenerate("Department",$TranslationIdDepartment);
?>
</table>


</center>

<center>
<h2>Tasks</h2>

<?
	$rsTasks = TaskGetByEmployee($Id);

	$titles = array('Id', 'Description', 'Project');

	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rsTasks)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"TaskView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Description']);
		$ColumnDescription = ProjectTranslate($reg['IdProject']);
		DatumLinkGenerate($ColumnDescription, "ProjectView.php?Id=".$reg['IdProject']);
		RowClose();
	}


	TableClose();	

	DbFreeResult($rsTasks);
?>
<center>
<h2>EmployeeSkills</h2>

<?
	$rsEmployeeSkills = EmployeeSkillGetByEmployee($Id);

	$titles = array('Id', 'Skill');

	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rsEmployeeSkills)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"EmployeeSkillView.php?Id=".$reg['Id']);
		$ColumnDescription = SkillTranslate($reg['IdSkill']);
		DatumLinkGenerate($ColumnDescription, "SkillView.php?Id=".$reg['IdSkill']);
		RowClose();
	}


	TableClose();	

	DbFreeResult($rsEmployeeSkills);
?>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
