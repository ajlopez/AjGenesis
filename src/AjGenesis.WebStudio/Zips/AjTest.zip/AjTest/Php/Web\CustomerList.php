<?
	$Page->Title = 'Customers';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/CustomerFunctions.inc.php');

	SessionPut('CustomerLink',PageCurrent());

	DbConnect();

	$rs = CustomerGetListView();

	$titles = array('Id', 'Name', 'Address');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="CustomerForm.php">New Customer...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"CustomerView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Name']);
		DatumGenerate($reg['Address']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
