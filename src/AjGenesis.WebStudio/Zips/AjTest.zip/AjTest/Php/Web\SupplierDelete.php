<?
	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');

	if (!isset($Id))
		PageExit();

	$sql = "delete from $Cfg[SqlPrefix]suppliers where Id = $Id";

	DbConnect();
	DbExecuteUpdate($sql);
	DbDisconnect();

	$Link = SessionGet("SupplierDeleteLink");
	SessionRemove("SupplierDeleteLink");

	if ($Link)
		PageAbsoluteRedirect($Link);
	else
		PageRedirect('SupplierList.php');

	exit;
?>
