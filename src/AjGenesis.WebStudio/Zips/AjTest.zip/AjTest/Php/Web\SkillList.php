<?
	$Page->Title = 'Skills';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/SkillFunctions.inc.php');

	SessionPut('SkillLink',PageCurrent());

	DbConnect();

	$rs = SkillGetListView();

	$titles = array('Id', 'Description');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="SkillForm.php">New Skill...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"SkillView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Description']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
