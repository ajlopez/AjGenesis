<?
	$Page->Title = 'Main';
	include_once('includes/Header.inc.php');
	include_once('includes/Footer.inc.php');
?>
