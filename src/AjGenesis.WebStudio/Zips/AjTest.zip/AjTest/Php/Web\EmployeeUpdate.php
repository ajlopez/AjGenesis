<?
	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/PostParameters.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Validations.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');

	DbConnect();

	if (ErrorHas()) {
		DbDisconnect();
		include('EmployeeForm.php');
		exit;
	}

	if (empty($Id))
		$sql = "Insert";
	else
		$sql = "Update";

	$sql .= " $Cfg[SqlPrefix]employees set
		EmployeeCode = '$EmployeeCode' , 
		LastName = '$LastName' , 
		FirstName = '$FirstName' , 
		IdDepartment = $IdDepartment 		";

	if (!empty($Id))
		$sql .= " where Id=$Id";

	DbExecuteUpdate($sql);

	DbDisconnect();

	$Link = SessionGet("EmployeeLink");
	SessionRemove("EmployeeLink");

	PageAbsoluteRedirect($Link);
	exit;
?>
