<?
	$Page->Title = 'Projects';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/ProjectFunctions.inc.php');

	SessionPut('ProjectLink',PageCurrent());

	DbConnect();

	$rs = ProjectGetListView();

	$titles = array('Id', 'Description');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="ProjectForm.php">New Project...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"ProjectView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Description']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
