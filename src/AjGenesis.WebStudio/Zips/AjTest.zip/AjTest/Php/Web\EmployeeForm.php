<?
	$Page->Title = 'Actualiza Employee';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');

	DbConnect();
	
	if (!ErrorHas() && isset($Id)) {
		$rs = EmployeeGetById($Id);
		$EmployeeCode = $rs['EmployeeCode'];
		$LastName = $rs['LastName'];
		$FirstName = $rs['FirstName'];
		$IdDepartment = $rs['IdDepartment'];

		$IsNew = 0;
	}	
	else if (isset($Id))
		$IsNew = 0;
	else {
		$Page->Title = "Nuevo Employee";
		$IsNew = 1;
	}

	$rsIdDepartment = TranslateQuery("$Cfg[SqlPrefix]departments","Description as Description");

	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeList.php">Employees</a>
&nbsp;
&nbsp;
<?
	if (!$IsNew) {
?>
<a href="EmployeeView.php?Id=<? echo $Id; ?>">Employee</a>
&nbsp;
&nbsp;
<?
	}
?>
</p>


<?
	ErrorRender();
?>

<p>

<form action="EmployeeUpdate.php" method=post>

<table cellspacing=1 cellpadding=2 class="form">
<?
	if (!$IsNew)
		FieldStaticGenerate("Id",$Id);

	FieldTextGenerate("EmployeeCode","Code",$EmployeeCode,30,False);
	FieldTextGenerate("LastName","Last Name",$LastName,30,False);
	FieldTextGenerate("FirstName","First Name",$FirstName,30,False);
	FieldComboRsGenerate("IdDepartment","Department",$rsIdDepartment,$IdDepartment,"Id","Description",false,False);

	FieldOkGenerate();
?>
</table>

<?
	if (!$IsNew)
		FieldIdGenerate($Id);
?>

</form>

</center>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
