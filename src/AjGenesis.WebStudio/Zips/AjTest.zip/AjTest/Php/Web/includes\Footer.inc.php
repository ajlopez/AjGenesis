<?
	include_once('Bottom.inc.php');
	include_once('End.inc.php');
?>