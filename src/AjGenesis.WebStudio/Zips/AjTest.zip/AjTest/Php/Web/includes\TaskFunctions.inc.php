<?

/*
 *	Functions
 * for Entity Task
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function TaskGetById($Id) {
	global $Cfg;

	$sql = "select Id, Description, IdEmployee, IdProject from $Cfg[SqlPrefix]tasks where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function TaskGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Description, IdEmployee, IdProject from $Cfg[SqlPrefix]tasks";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function TaskGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Description, IdEmployee, IdProject from $Cfg[SqlPrefix]tasks";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function TaskGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function TaskInsert($Description, $IdEmployee, $IdProject) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]tasks set
		Description = '$Description',
		IdEmployee = $IdEmployee,
		IdProject = $IdProject";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function TaskUpdate($Id, $Description, $IdEmployee, $IdProject) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]tasks set
		Description = '$Description',
		IdEmployee = $IdEmployee,
		IdProject = $IdProject where Id = $Id";

	DbExecuteUpdate($sql);
}

function TaskDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]tasks where Id = $Id";
	DbExecuteUpdate($sql);
}

function TaskTranslate($Id) {
	global $TaskNames;
	global $Cfg;

	if ($TaskNames[$Id])
		return $TaskNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]tasks",$Id,"Description");

	$TaskNames[$Id] = $description;

	return $description;
}


function TaskGetByEmployee($IdEmployee) {
	return TaskGetList("IdEmployee = $IdEmployee");
}

function TaskGetByProject($IdProject) {
	return TaskGetList("IdProject = $IdProject");
}

?>
