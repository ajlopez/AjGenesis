<?

/*
 *	Functions
 * for Entity Supplier
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function SupplierGetById($Id) {
	global $Cfg;

	$sql = "select Id, Name, Address from $Cfg[SqlPrefix]suppliers where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function SupplierGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Name, Address from $Cfg[SqlPrefix]suppliers";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function SupplierGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Name, Address from $Cfg[SqlPrefix]suppliers";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function SupplierGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function SupplierInsert($Name, $Address) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]suppliers set
		Name = '$Name',
		Address = '$Address'";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function SupplierUpdate($Id, $Name, $Address) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]suppliers set
		Name = '$Name',
		Address = '$Address' where Id = $Id";

	DbExecuteUpdate($sql);
}

function SupplierDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]suppliers where Id = $Id";
	DbExecuteUpdate($sql);
}

function SupplierTranslate($Id) {
	global $SupplierNames;
	global $Cfg;

	if ($SupplierNames[$Id])
		return $SupplierNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]suppliers",$Id,"Name");

	$SupplierNames[$Id] = $description;

	return $description;
}


?>
