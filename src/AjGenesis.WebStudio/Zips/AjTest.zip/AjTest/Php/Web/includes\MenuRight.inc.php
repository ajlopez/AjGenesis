<table border="0" width="100%" class="TemplateColorFondoContenido" cellpadding="0" cellspacing="0">
	<td width="100%">

		<table width="100%" border=0 cellpadding="0" cellspacing="1">
		
			<tr>
				<td  width="100%">
					<table width="100%" cellpadding="0" cellspacing="0">
						<td class="TemplateMenuDerecho" height="18">
							Menu A
						</td>
					</table>
				</td>
			</tr>
		
			<tr>
				<td>
					<table width="100%" class="TemplateColorMenuIzquierdoItem" cellpadding="0" cellspacing="0">
						<td class="TemplateMenuDerecho" height="18">
							Menu B
						</td>
					</table>
				</td>
			</tr>
					
		
			<tr>
				<td>
					<table width="100%" cellpadding="1" cellspacing="2">
						<tr>
							<td class="TemplateMenuDerechoItem">	
								Opcion 1
							</td>
						</tr>
						<tr>
							<td class="TemplateMenuDerechoItem">	
								Opcion 2
							</td>
						</tr>
						<tr>
							<td class="TemplateMenuDerechoItem">	
								Opcion 3
							</td>
						</tr>
					</table>
			</td>
			</tr>
			
			<tr>
				<td>
					<table width="100%" class="TemplateColorMenuIzquierdoItem" cellpadding="0" cellspacing="0">
						<td class="TemplateMenuDerecho" height="18">
							Menu C
						</td>
					</table>
				</td>
			</tr>
			
			<tr>
				<td>
					<table width="100%" class="TemplateColorMenuIzquierdoItem" cellpadding="0" cellspacing="0">
						<td class="TemplateMenuDerecho" height="18">
							Menu D
						</td>
					</table>
				</td>
			</tr>
		</table>	

	</td>
</table>