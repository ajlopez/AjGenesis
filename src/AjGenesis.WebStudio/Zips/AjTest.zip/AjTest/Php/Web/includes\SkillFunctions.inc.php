<?

/*
 *	Functions
 * for Entity Skill
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function SkillGetById($Id) {
	global $Cfg;

	$sql = "select Id, Description from $Cfg[SqlPrefix]skills where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function SkillGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Description from $Cfg[SqlPrefix]skills";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function SkillGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Description from $Cfg[SqlPrefix]skills";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function SkillGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function SkillInsert($Description) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]skills set
		Description = '$Description'";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function SkillUpdate($Id, $Description) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]skills set
		Description = '$Description' where Id = $Id";

	DbExecuteUpdate($sql);
}

function SkillDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]skills where Id = $Id";
	DbExecuteUpdate($sql);
}

function SkillTranslate($Id) {
	global $SkillNames;
	global $Cfg;

	if ($SkillNames[$Id])
		return $SkillNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]skills",$Id,"Description");

	$SkillNames[$Id] = $description;

	return $description;
}


?>
