<?

/*
 *	Functions
 * for Entity Customer
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function CustomerGetById($Id) {
	global $Cfg;

	$sql = "select Id, Name, Address from $Cfg[SqlPrefix]customers where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function CustomerGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Name, Address from $Cfg[SqlPrefix]customers";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function CustomerGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Name, Address from $Cfg[SqlPrefix]customers";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function CustomerGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function CustomerInsert($Name, $Address) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]customers set
		Name = '$Name',
		Address = '$Address'";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function CustomerUpdate($Id, $Name, $Address) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]customers set
		Name = '$Name',
		Address = '$Address' where Id = $Id";

	DbExecuteUpdate($sql);
}

function CustomerDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]customers where Id = $Id";
	DbExecuteUpdate($sql);
}

function CustomerTranslate($Id) {
	global $CustomerNames;
	global $Cfg;

	if ($CustomerNames[$Id])
		return $CustomerNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]customers",$Id,"Name");

	$CustomerNames[$Id] = $description;

	return $description;
}


?>
