<?
	foreach ($HTTP_POST_VARS as $name => $value)
		$$name = $value;
?>