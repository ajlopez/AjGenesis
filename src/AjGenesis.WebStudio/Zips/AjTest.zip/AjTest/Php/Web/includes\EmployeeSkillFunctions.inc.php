<?

/*
 *	Functions
 * for Entity EmployeeSkill
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function EmployeeSkillGetById($Id) {
	global $Cfg;

	$sql = "select Id, IdEmployee, IdSkill from $Cfg[SqlPrefix]employeeskills where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function EmployeeSkillGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, IdEmployee, IdSkill from $Cfg[SqlPrefix]employeeskills";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function EmployeeSkillGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, IdEmployee, IdSkill from $Cfg[SqlPrefix]employeeskills";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function EmployeeSkillGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function EmployeeSkillInsert($IdEmployee, $IdSkill) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]employeeskills set
		IdEmployee = $IdEmployee,
		IdSkill = $IdSkill";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function EmployeeSkillUpdate($Id, $IdEmployee, $IdSkill) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]employeeskills set
		IdEmployee = $IdEmployee,
		IdSkill = $IdSkill where Id = $Id";

	DbExecuteUpdate($sql);
}

function EmployeeSkillDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]employeeskills where Id = $Id";
	DbExecuteUpdate($sql);
}

function EmployeeSkillTranslate($Id) {
	global $EmployeeSkillNames;
	global $Cfg;

	if ($EmployeeSkillNames[$Id])
		return $EmployeeSkillNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]employeeskills",$Id,"IdEmployee");

	$EmployeeSkillNames[$Id] = $description;

	return $description;
}


function EmployeeSkillGetByEmployee($IdEmployee) {
	return EmployeeSkillGetList("IdEmployee = $IdEmployee");
}

function EmployeeSkillGetBySkill($IdSkill) {
	return EmployeeSkillGetList("IdSkill = $IdSkill");
}

?>
