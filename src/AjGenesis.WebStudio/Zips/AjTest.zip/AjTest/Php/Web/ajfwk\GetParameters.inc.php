<?
	foreach ($HTTP_GET_VARS as $name => $value)
		$$name = $value;
?>