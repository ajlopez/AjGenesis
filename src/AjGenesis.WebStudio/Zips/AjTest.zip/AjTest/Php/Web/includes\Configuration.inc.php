<?
$Cfg['SiteName']='AjTest';
//$Cfg['SiteLogo']='AjTest.gif';
$Cfg['SiteDescription']='AjTest';

$Cfg['SqlType']='MySql';
$Cfg['SqlHost']='localhost';
$Cfg['SqlBase']='ajtest';
$Cfg['SqlUser']='root';
$Cfg['SqlPassword']='';
$Cfg['SqlPrefix']='ajtest_';
?>
