<?
include_once('Configuration.inc.php');
include_once('Database' . $Cfg['SqlType'] . '.inc.php');
?>