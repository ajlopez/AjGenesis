<?

/*
 *	Functions
 * for Entity Project
 *
 */

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

function ProjectGetById($Id) {
	global $Cfg;

	$sql = "select Id, Description from $Cfg[SqlPrefix]projects where Id = $Id";

	$rs = DbExecuteQuery($sql);
	return DbNextRow($rs);
}

function ProjectGetList($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Description from $Cfg[SqlPrefix]projects";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function ProjectGetListView($where='',$order='') {
	global $Cfg;

	$sql = "select Id, Id, Description from $Cfg[SqlPrefix]projects";

	if ($where)
		$sql .= " where $where";
	if (!$order)
		$order = 'Id';
	$sql .= " order by $order";

	return DbExecuteQuery($sql);
}

function ProjectGetView($where='',$order='') {
	global $Cfg;

}

//	function GetListBy...
//	function GetViewBy...

function ProjectInsert($Description) {
	global $Cfg;

	$sql = "insert $Cfg[SqlPrefix]projects set
		Description = '$Description'";

	DbExecuteUpdate($sql);

	return DbLastId();
}

function ProjectUpdate($Id, $Description) {
	global $Cfg;

	$sql = "update $Cfg[SqlPrefix]projects set
		Description = '$Description' where Id = $Id";

	DbExecuteUpdate($sql);
}

function ProjectDelete($Id) {
	global $Cfg;

	$sql = "delete from $Cfg[SqlPrefix]projects where Id = $Id";
	DbExecuteUpdate($sql);
}

function ProjectTranslate($Id) {
	global $ProjectNames;
	global $Cfg;

	if ($ProjectNames[$Id])
		return $ProjectNames[$Id];

	$description = TranslateDescription("$Cfg[SqlPrefix]projects",$Id,"Description");

	$ProjectNames[$Id] = $description;

	return $description;
}


?>
