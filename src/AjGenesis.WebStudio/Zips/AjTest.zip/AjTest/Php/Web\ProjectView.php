<?
	$Page->Title = 'Project';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/ProjectFunctions.inc.php');
	include_once($Page->Prefix.'includes/TaskFunctions.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');

	DbConnect();
	
	SessionPut('ProjectLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = ProjectGetById($Id);
	$Description = $rs['Description'];


	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="ProjectList.php">Projects</a>
&nbsp;
&nbsp;
<a href="ProjectForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="ProjectDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Description",$Description);
?>
</table>


</center>

<center>
<h2>Tasks</h2>

<?
	$rsTasks = TaskGetByProject($Id);

	$titles = array('Id', 'Description', 'Employee');

	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rsTasks)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"TaskView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Description']);
		$ColumnDescription = EmployeeTranslate($reg['IdEmployee']);
		DatumLinkGenerate($ColumnDescription, "EmployeeView.php?Id=".$reg['IdEmployee']);
		RowClose();
	}


	TableClose();	

	DbFreeResult($rsTasks);
?>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
