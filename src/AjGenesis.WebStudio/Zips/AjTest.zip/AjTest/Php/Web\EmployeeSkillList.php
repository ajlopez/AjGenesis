<?
	$Page->Title = 'EmployeeSkills';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/EmployeeSkillFunctions.inc.php');
	include_once($Page->Prefix . 'includes/EmployeeFunctions.inc.php');
	include_once($Page->Prefix . 'includes/SkillFunctions.inc.php');

	SessionPut('EmployeeSkillLink',PageCurrent());

	DbConnect();

	$rs = EmployeeSkillGetListView();

	$titles = array('Id', 'Employee', 'Skill');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeSkillForm.php">New EmployeeSkill...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"EmployeeSkillView.php?Id=".$reg['Id']);
		$ColumnDescription = EmployeeTranslate($reg['IdEmployee']);
		DatumLinkGenerate($ColumnDescription, "EmployeeView.php?Id=".$reg['IdEmployee']);
		$ColumnDescription = SkillTranslate($reg['IdSkill']);
		DatumLinkGenerate($ColumnDescription, "SkillView.php?Id=".$reg['IdSkill']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
