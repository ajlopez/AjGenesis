<?
	$Page->Title = 'Actualiza Task';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/TaskFunctions.inc.php');

	DbConnect();
	
	if (!ErrorHas() && isset($Id)) {
		$rs = TaskGetById($Id);
		$Description = $rs['Description'];
		$IdEmployee = $rs['IdEmployee'];
		$IdProject = $rs['IdProject'];

		$IsNew = 0;
	}	
	else if (isset($Id))
		$IsNew = 0;
	else {
		$Page->Title = "Nuevo Task";
		$IsNew = 1;
	}

	$rsIdEmployee = TranslateQuery("$Cfg[SqlPrefix]employees","EmployeeCode as EmployeeCode");
	$rsIdProject = TranslateQuery("$Cfg[SqlPrefix]projects","Description as Description");

	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="TaskList.php">Tasks</a>
&nbsp;
&nbsp;
<?
	if (!$IsNew) {
?>
<a href="TaskView.php?Id=<? echo $Id; ?>">Task</a>
&nbsp;
&nbsp;
<?
	}
?>
</p>


<?
	ErrorRender();
?>

<p>

<form action="TaskUpdate.php" method=post>

<table cellspacing=1 cellpadding=2 class="form">
<?
	if (!$IsNew)
		FieldStaticGenerate("Id",$Id);

	FieldTextGenerate("Description","Description",$Description,30,False);
	FieldComboRsGenerate("IdEmployee","Employee",$rsIdEmployee,$IdEmployee,"Id","EmployeeCode",false,False);
	FieldComboRsGenerate("IdProject","Project",$rsIdProject,$IdProject,"Id","Description",false,False);

	FieldOkGenerate();
?>
</table>

<?
	if (!$IsNew)
		FieldIdGenerate($Id);
?>

</form>

</center>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
