<?
	$Page->Title = 'Departments';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/DepartmentFunctions.inc.php');

	SessionPut('DepartmentLink',PageCurrent());

	DbConnect();

	$rs = DepartmentGetListView();

	$titles = array('Id', 'Description');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="DepartmentForm.php">New Department...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"DepartmentView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Description']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
