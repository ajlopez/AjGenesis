<?
	$Page->Title = 'Suppliers';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/SupplierFunctions.inc.php');

	SessionPut('SupplierLink',PageCurrent());

	DbConnect();

	$rs = SupplierGetListView();

	$titles = array('Id', 'Name', 'Address');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="SupplierForm.php">New Supplier...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"SupplierView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Name']);
		DatumGenerate($reg['Address']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
