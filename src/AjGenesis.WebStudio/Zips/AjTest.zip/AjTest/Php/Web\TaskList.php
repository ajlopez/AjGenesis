<?
	$Page->Title = 'Tasks';

	include_once($Page->Prefix . 'ajfwk/Database.inc.php');
	include_once($Page->Prefix . 'ajfwk/Tables.inc.php');
	include_once($Page->Prefix . 'ajfwk/Pages.inc.php');
	include_once($Page->Prefix . 'ajfwk/Session.inc.php');

	include_once($Page->Prefix . 'includes/Enumerations.inc.php');
	include_once($Page->Prefix . 'includes/TaskFunctions.inc.php');
	include_once($Page->Prefix . 'includes/EmployeeFunctions.inc.php');
	include_once($Page->Prefix . 'includes/ProjectFunctions.inc.php');

	SessionPut('TaskLink',PageCurrent());

	DbConnect();

	$rs = TaskGetListView();

	$titles = array('Id', 'Description', 'Employee', 'Project');

	include_once($Page->Prefix . 'includes/Header.inc.php');
?>

<center>

<p>
<a href="TaskForm.php">New Task...</a>
<p>

<?		
	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rs)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"TaskView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Description']);
		$ColumnDescription = EmployeeTranslate($reg['IdEmployee']);
		DatumLinkGenerate($ColumnDescription, "EmployeeView.php?Id=".$reg['IdEmployee']);
		$ColumnDescription = ProjectTranslate($reg['IdProject']);
		DatumLinkGenerate($ColumnDescription, "ProjectView.php?Id=".$reg['IdProject']);
		RowClose();
	}

	TableClose();
?>

</center>

<?
	include_once($Page->Prefix . 'includes/Footer.inc.php');
	DbDisconnect();
?>
