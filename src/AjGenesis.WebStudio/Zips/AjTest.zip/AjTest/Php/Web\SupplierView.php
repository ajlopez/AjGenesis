<?
	$Page->Title = 'Supplier';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/SupplierFunctions.inc.php');

	DbConnect();
	
	SessionPut('SupplierLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = SupplierGetById($Id);
	$Name = $rs['Name'];
	$Address = $rs['Address'];


	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="SupplierList.php">Suppliers</a>
&nbsp;
&nbsp;
<a href="SupplierForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="SupplierDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Name",$Name);
	FieldStaticGenerate("Address",$Address);
?>
</table>


</center>


<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
