<?
	$Page->Title = 'Skill';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/SkillFunctions.inc.php');
	include_once($Page->Prefix.'includes/EmployeeSkillFunctions.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');

	DbConnect();
	
	SessionPut('SkillLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = SkillGetById($Id);
	$Description = $rs['Description'];


	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="SkillList.php">Skills</a>
&nbsp;
&nbsp;
<a href="SkillForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="SkillDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Description",$Description);
?>
</table>


</center>

<center>
<h2>EmployeeSkills</h2>

<?
	$rsEmployeeSkills = EmployeeSkillGetBySkill($Id);

	$titles = array('Id', 'Employee');

	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rsEmployeeSkills)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"EmployeeSkillView.php?Id=".$reg['Id']);
		$ColumnDescription = EmployeeTranslate($reg['IdEmployee']);
		DatumLinkGenerate($ColumnDescription, "EmployeeView.php?Id=".$reg['IdEmployee']);
		RowClose();
	}


	TableClose();	

	DbFreeResult($rsEmployeeSkills);
?>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
