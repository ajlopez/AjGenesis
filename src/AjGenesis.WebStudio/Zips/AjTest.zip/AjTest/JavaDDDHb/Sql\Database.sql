
--
--		Project:		AjTest
--		Description:	AjTest
--



--
--		Entity:		Employee
--		Description:	Employee
--


drop table if exists employees;


create table employees (
		Id int NOT NULL auto_increment,
	
		EmployeeCode varchar(20),
	
		LastName varchar(100),
	
		FirstName varchar(100),
	
		IdDepartment int,
		primary key (Id)
);


--
--		Entity:		Department
--		Description:	Department
--


drop table if exists departments;


create table departments (
		Id int NOT NULL auto_increment,
	
		Description varchar(200),
		primary key (Id)
);


--
--		Entity:		Supplier
--		Description:	Supplier
--


drop table if exists suppliers;


create table suppliers (
		Id int NOT NULL auto_increment,
	
		Name varchar(200),
	
		Address varchar(200),
		primary key (Id)
);


--
--		Entity:		Customer
--		Description:	Customer
--


drop table if exists customers;


create table customers (
		Id int NOT NULL auto_increment,
	
		Name varchar(200),
	
		Address varchar(200),
		primary key (Id)
);


--
--		Entity:		Project
--		Description:	Project
--


drop table if exists projects;


create table projects (
		Id int NOT NULL auto_increment,
	
		Description varchar(200),
		primary key (Id)
);


--
--		Entity:		Task
--		Description:	Task
--


drop table if exists tasks;


create table tasks (
		Id int NOT NULL auto_increment,
	
		Description varchar(200),
	
		IdEmployee int,
	
		IdProject int,
		primary key (Id)
);


--
--		Entity:		Skill
--		Description:	Skill
--


drop table if exists skills;


create table skills (
		Id int NOT NULL auto_increment,
	
		Description varchar(200),
		primary key (Id)
);


--
--		Entity:		EmployeeSkill
--		Description:	EmployeeSkill
--


drop table if exists employeeskills;


create table employeeskills (
		Id int NOT NULL auto_increment,
	
		IdEmployee int,
	
		IdSkill int,
		primary key (Id)
);

