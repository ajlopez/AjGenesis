
/*
 *	Project AjTest
 *		AjTest
 *	Services	CustomerServices
 *		Customer
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class CustomerManager {
	public static Customer getById(int id) throws Exception {
		return CustomerRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return CustomerRepository.getAll();
	}
	
	public static void insert(Customer entity) throws Exception {
		CustomerRepository.insert(entity);
	}
	
	public static void update(Customer entity) throws Exception {
		CustomerRepository.update(entity);
	}
	
	public static void delete(Customer entity) throws Exception {
		CustomerRepository.delete(entity);
	}
}

