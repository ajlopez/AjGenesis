
/*
 *	Project	AjTest
 *		AjTest
 *	Department	Department
 *		Department
 *	
 */

package com.ajlopez.ajtest.infrastructure.data;

import java.util.*;
import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;

public class DepartmentDAO {
	public Department getById(int id) throws Exception {
		return (Department) AjHibernate.getSession().get(Department.class,new Integer(id));
	}

	public List getAll() throws Exception {
		Query query = (AjHibernate.getSession()).createQuery("from com.ajlopez.ajtest.domain.entities.Department");
		return query.list();
	}

	public void insert(Department entity) throws Exception {
		AjHibernate.getSession().save(entity);
	}

	public void update(Department entity) throws Exception {
		AjHibernate.getSession().update(entity);
	}

	public void delete(Department entity) throws Exception {
		AjHibernate.getSession().delete(entity);
	}
}

