
/*
 *	Project AjTest
 *		AjTest
 *	Services	ProjectServices
 *		Project
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class ProjectManager {
	public static Project getById(int id) throws Exception {
		return ProjectRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return ProjectRepository.getAll();
	}
	
	public static void insert(Project entity) throws Exception {
		ProjectRepository.insert(entity);
	}
	
	public static void update(Project entity) throws Exception {
		ProjectRepository.update(entity);
	}
	
	public static void delete(Project entity) throws Exception {
		ProjectRepository.delete(entity);
	}
}

