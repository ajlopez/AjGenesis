
/*
 *	Project AjTest
 *		AjTest
 *	Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class EmployeeSkill {

//	Private Fields

	private int id; 
	private Employee employee; 
	private Skill skill; 


//	Default Constructor

	public EmployeeSkill() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee value) {
		employee = value;
	}
	
	public Skill getSkill() {
		return skill;
	}

	public void setSkill(Skill value) {
		skill = value;
	}

}

