
/*
 *	Project AjTest
 *		AjTest
 *	Services	EmployeeServices
 *		Employee
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class EmployeeServices {
	public static Employee getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Employee entity = null;

		try {
			entity = EmployeeManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = EmployeeManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Employee entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			EmployeeManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Employee entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			EmployeeManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Employee entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			EmployeeManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

