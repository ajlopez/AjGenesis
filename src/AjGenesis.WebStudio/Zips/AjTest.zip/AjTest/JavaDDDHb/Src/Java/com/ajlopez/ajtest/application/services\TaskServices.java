
/*
 *	Project AjTest
 *		AjTest
 *	Services	TaskServices
 *		Task
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class TaskServices {
	public static Task getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Task entity = null;

		try {
			entity = TaskManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = TaskManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Task entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			TaskManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Task entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			TaskManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Task entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			TaskManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

