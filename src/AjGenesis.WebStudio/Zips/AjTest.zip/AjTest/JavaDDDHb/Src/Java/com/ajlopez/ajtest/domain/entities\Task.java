
/*
 *	Project AjTest
 *		AjTest
 *	Entity	Task
 *		Task
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class Task {

//	Private Fields

	private int id; 
	private String description; 
	private Employee employee; 
	private Project project; 


//	Default Constructor

	public Task() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String value) {
		description = value;
	}
	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee value) {
		employee = value;
	}
	
	public Project getProject() {
		return project;
	}

	public void setProject(Project value) {
		project = value;
	}

}

