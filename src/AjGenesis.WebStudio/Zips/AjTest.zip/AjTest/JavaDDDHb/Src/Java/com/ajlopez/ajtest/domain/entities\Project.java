
/*
 *	Project AjTest
 *		AjTest
 *	Entity	Project
 *		Project
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class Project {

//	Private Fields

	private int id; 
	private String description; 
	private List tasks; 


//	Default Constructor

	public Project() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String value) {
		description = value;
	}
	
	public List getTasks() {
		return tasks;
	}

	public void setTasks(List value) {
		tasks = value;
	}

}

