
/*
 *	Project AjTest
 *		AjTest
 *	Repository for Entity	Skill
 *		Skill
 *	
 */

package com.ajlopez.ajtest.domain.repositories;

import java.util.*;

import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class SkillRepository {
	private static SkillDAO dao = new SkillDAO();

	public static void insert(Skill entity) throws Exception {
		dao.insert(entity);
	}

	public static void update(Skill entity) throws Exception {
		dao.update(entity);
	}

	public static void delete(Skill entity) throws Exception {
		dao.delete(entity);
	}

	public static Skill getById(int id) throws Exception {
		if (id==0)
			return null;
		return dao.getById(id);
	}

	public static List getAll() throws Exception {
		return dao.getAll();
	}
}

