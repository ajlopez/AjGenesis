
/*
 *	Project AjTest
 *		AjTest
 *	Services	DepartmentServices
 *		Department
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class DepartmentManager {
	public static Department getById(int id) throws Exception {
		return DepartmentRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return DepartmentRepository.getAll();
	}
	
	public static void insert(Department entity) throws Exception {
		DepartmentRepository.insert(entity);
	}
	
	public static void update(Department entity) throws Exception {
		DepartmentRepository.update(entity);
	}
	
	public static void delete(Department entity) throws Exception {
		DepartmentRepository.delete(entity);
	}
}

