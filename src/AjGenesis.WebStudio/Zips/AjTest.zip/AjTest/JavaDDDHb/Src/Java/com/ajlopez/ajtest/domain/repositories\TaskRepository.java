
/*
 *	Project AjTest
 *		AjTest
 *	Repository for Entity	Task
 *		Task
 *	
 */

package com.ajlopez.ajtest.domain.repositories;

import java.util.*;

import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class TaskRepository {
	private static TaskDAO dao = new TaskDAO();

	public static void insert(Task entity) throws Exception {
		dao.insert(entity);
	}

	public static void update(Task entity) throws Exception {
		dao.update(entity);
	}

	public static void delete(Task entity) throws Exception {
		dao.delete(entity);
	}

	public static Task getById(int id) throws Exception {
		if (id==0)
			return null;
		return dao.getById(id);
	}

	public static List getAll() throws Exception {
		return dao.getAll();
	}
}

