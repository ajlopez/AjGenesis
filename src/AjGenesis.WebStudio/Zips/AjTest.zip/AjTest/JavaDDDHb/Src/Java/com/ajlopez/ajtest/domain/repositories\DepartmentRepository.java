
/*
 *	Project AjTest
 *		AjTest
 *	Repository for Entity	Department
 *		Department
 *	
 */

package com.ajlopez.ajtest.domain.repositories;

import java.util.*;

import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class DepartmentRepository {
	private static DepartmentDAO dao = new DepartmentDAO();

	public static void insert(Department entity) throws Exception {
		dao.insert(entity);
	}

	public static void update(Department entity) throws Exception {
		dao.update(entity);
	}

	public static void delete(Department entity) throws Exception {
		dao.delete(entity);
	}

	public static Department getById(int id) throws Exception {
		if (id==0)
			return null;
		return dao.getById(id);
	}

	public static List getAll() throws Exception {
		return dao.getAll();
	}
}

