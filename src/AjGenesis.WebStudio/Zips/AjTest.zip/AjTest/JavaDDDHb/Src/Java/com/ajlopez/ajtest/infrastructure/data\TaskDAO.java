
/*
 *	Project	AjTest
 *		AjTest
 *	Task	Task
 *		Task
 *	
 */

package com.ajlopez.ajtest.infrastructure.data;

import java.util.*;
import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;

public class TaskDAO {
	public Task getById(int id) throws Exception {
		return (Task) AjHibernate.getSession().get(Task.class,new Integer(id));
	}

	public List getAll() throws Exception {
		Query query = (AjHibernate.getSession()).createQuery("from com.ajlopez.ajtest.domain.entities.Task");
		return query.list();
	}

	public void insert(Task entity) throws Exception {
		AjHibernate.getSession().save(entity);
	}

	public void update(Task entity) throws Exception {
		AjHibernate.getSession().update(entity);
	}

	public void delete(Task entity) throws Exception {
		AjHibernate.getSession().delete(entity);
	}
}

