
/*
 *	Project AjTest
 *		AjTest
 *	Services	EmployeeSkillServices
 *		EmployeeSkill
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class EmployeeSkillManager {
	public static EmployeeSkill getById(int id) throws Exception {
		return EmployeeSkillRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return EmployeeSkillRepository.getAll();
	}
	
	public static void insert(EmployeeSkill entity) throws Exception {
		EmployeeSkillRepository.insert(entity);
	}
	
	public static void update(EmployeeSkill entity) throws Exception {
		EmployeeSkillRepository.update(entity);
	}
	
	public static void delete(EmployeeSkill entity) throws Exception {
		EmployeeSkillRepository.delete(entity);
	}
}

