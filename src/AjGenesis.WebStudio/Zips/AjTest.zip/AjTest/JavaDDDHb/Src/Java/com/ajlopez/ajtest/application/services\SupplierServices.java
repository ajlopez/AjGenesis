
/*
 *	Project AjTest
 *		AjTest
 *	Services	SupplierServices
 *		Supplier
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class SupplierServices {
	public static Supplier getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Supplier entity = null;

		try {
			entity = SupplierManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = SupplierManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Supplier entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			SupplierManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Supplier entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			SupplierManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Supplier entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			SupplierManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

