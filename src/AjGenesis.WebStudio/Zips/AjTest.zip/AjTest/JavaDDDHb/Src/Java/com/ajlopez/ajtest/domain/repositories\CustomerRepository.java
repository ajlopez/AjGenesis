
/*
 *	Project AjTest
 *		AjTest
 *	Repository for Entity	Customer
 *		Customer
 *	
 */

package com.ajlopez.ajtest.domain.repositories;

import java.util.*;

import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class CustomerRepository {
	private static CustomerDAO dao = new CustomerDAO();

	public static void insert(Customer entity) throws Exception {
		dao.insert(entity);
	}

	public static void update(Customer entity) throws Exception {
		dao.update(entity);
	}

	public static void delete(Customer entity) throws Exception {
		dao.delete(entity);
	}

	public static Customer getById(int id) throws Exception {
		if (id==0)
			return null;
		return dao.getById(id);
	}

	public static List getAll() throws Exception {
		return dao.getAll();
	}
}

