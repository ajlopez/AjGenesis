
/*
 *	Project	AjTest
 *		AjTest
 *	EmployeeSkill	EmployeeSkill
 *		EmployeeSkill
 *	
 */

package com.ajlopez.ajtest.infrastructure.data;

import java.util.*;
import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;

public class EmployeeSkillDAO {
	public EmployeeSkill getById(int id) throws Exception {
		return (EmployeeSkill) AjHibernate.getSession().get(EmployeeSkill.class,new Integer(id));
	}

	public List getAll() throws Exception {
		Query query = (AjHibernate.getSession()).createQuery("from com.ajlopez.ajtest.domain.entities.EmployeeSkill");
		return query.list();
	}

	public void insert(EmployeeSkill entity) throws Exception {
		AjHibernate.getSession().save(entity);
	}

	public void update(EmployeeSkill entity) throws Exception {
		AjHibernate.getSession().update(entity);
	}

	public void delete(EmployeeSkill entity) throws Exception {
		AjHibernate.getSession().delete(entity);
	}
}

