
/*
 *	Project AjTest
 *		AjTest
 *	Services	SkillServices
 *		Skill
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class SkillServices {
	public static Skill getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Skill entity = null;

		try {
			entity = SkillManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = SkillManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Skill entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			SkillManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Skill entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			SkillManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Skill entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			SkillManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

