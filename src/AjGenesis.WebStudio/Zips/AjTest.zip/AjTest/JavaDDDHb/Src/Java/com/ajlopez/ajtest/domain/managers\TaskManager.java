
/*
 *	Project AjTest
 *		AjTest
 *	Services	TaskServices
 *		Task
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class TaskManager {
	public static Task getById(int id) throws Exception {
		return TaskRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return TaskRepository.getAll();
	}
	
	public static void insert(Task entity) throws Exception {
		TaskRepository.insert(entity);
	}
	
	public static void update(Task entity) throws Exception {
		TaskRepository.update(entity);
	}
	
	public static void delete(Task entity) throws Exception {
		TaskRepository.delete(entity);
	}
}

