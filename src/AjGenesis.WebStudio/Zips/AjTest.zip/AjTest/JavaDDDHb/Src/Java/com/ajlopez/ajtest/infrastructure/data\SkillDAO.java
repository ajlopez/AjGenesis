
/*
 *	Project	AjTest
 *		AjTest
 *	Skill	Skill
 *		Skill
 *	
 */

package com.ajlopez.ajtest.infrastructure.data;

import java.util.*;
import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;

public class SkillDAO {
	public Skill getById(int id) throws Exception {
		return (Skill) AjHibernate.getSession().get(Skill.class,new Integer(id));
	}

	public List getAll() throws Exception {
		Query query = (AjHibernate.getSession()).createQuery("from com.ajlopez.ajtest.domain.entities.Skill");
		return query.list();
	}

	public void insert(Skill entity) throws Exception {
		AjHibernate.getSession().save(entity);
	}

	public void update(Skill entity) throws Exception {
		AjHibernate.getSession().update(entity);
	}

	public void delete(Skill entity) throws Exception {
		AjHibernate.getSession().delete(entity);
	}
}

