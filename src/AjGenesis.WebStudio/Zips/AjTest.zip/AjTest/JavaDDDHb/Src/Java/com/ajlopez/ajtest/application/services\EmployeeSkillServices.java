
/*
 *	Project AjTest
 *		AjTest
 *	Services	EmployeeSkillServices
 *		EmployeeSkill
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class EmployeeSkillServices {
	public static EmployeeSkill getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		EmployeeSkill entity = null;

		try {
			entity = EmployeeSkillManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = EmployeeSkillManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(EmployeeSkill entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			EmployeeSkillManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(EmployeeSkill entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			EmployeeSkillManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(EmployeeSkill entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			EmployeeSkillManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

