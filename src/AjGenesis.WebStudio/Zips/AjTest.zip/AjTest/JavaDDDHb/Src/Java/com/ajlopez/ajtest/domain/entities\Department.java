
/*
 *	Project AjTest
 *		AjTest
 *	Entity	Department
 *		Department
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class Department {

//	Private Fields

	private int id; 
	private String description; 
	private List employees; 


//	Default Constructor

	public Department() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String value) {
		description = value;
	}
	
	public List getEmployees() {
		return employees;
	}

	public void setEmployees(List value) {
		employees = value;
	}

}

