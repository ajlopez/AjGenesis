
/*
 *	Project AjTest
 *		AjTest
 *	Services	CustomerServices
 *		Customer
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class CustomerServices {
	public static Customer getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Customer entity = null;

		try {
			entity = CustomerManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = CustomerManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Customer entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			CustomerManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Customer entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			CustomerManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Customer entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			CustomerManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

