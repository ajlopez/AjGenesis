
/*
 *	Project AjTest
 *		AjTest
 *	Services	SkillServices
 *		Skill
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class SkillManager {
	public static Skill getById(int id) throws Exception {
		return SkillRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return SkillRepository.getAll();
	}
	
	public static void insert(Skill entity) throws Exception {
		SkillRepository.insert(entity);
	}
	
	public static void update(Skill entity) throws Exception {
		SkillRepository.update(entity);
	}
	
	public static void delete(Skill entity) throws Exception {
		SkillRepository.delete(entity);
	}
}

