
/*
 *	Project AjTest
 *		AjTest
 *	Services	SupplierServices
 *		Supplier
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class SupplierManager {
	public static Supplier getById(int id) throws Exception {
		return SupplierRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return SupplierRepository.getAll();
	}
	
	public static void insert(Supplier entity) throws Exception {
		SupplierRepository.insert(entity);
	}
	
	public static void update(Supplier entity) throws Exception {
		SupplierRepository.update(entity);
	}
	
	public static void delete(Supplier entity) throws Exception {
		SupplierRepository.delete(entity);
	}
}

