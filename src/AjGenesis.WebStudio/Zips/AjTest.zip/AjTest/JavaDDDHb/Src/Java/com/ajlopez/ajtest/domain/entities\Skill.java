
/*
 *	Project AjTest
 *		AjTest
 *	Entity	Skill
 *		Skill
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class Skill {

//	Private Fields

	private int id; 
	private String description; 
	private List employeeSkills; 


//	Default Constructor

	public Skill() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String value) {
		description = value;
	}
	
	public List getEmployeeSkills() {
		return employeeSkills;
	}

	public void setEmployeeSkills(List value) {
		employeeSkills = value;
	}

}

