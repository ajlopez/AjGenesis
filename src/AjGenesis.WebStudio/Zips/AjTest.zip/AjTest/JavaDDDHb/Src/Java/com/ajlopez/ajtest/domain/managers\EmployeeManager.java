
/*
 *	Project AjTest
 *		AjTest
 *	Services	EmployeeServices
 *		Employee
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.domain.repositories.*;

public class EmployeeManager {
	public static Employee getById(int id) throws Exception {
		return EmployeeRepository.getById(id);
	}

	public static List getAll() throws Exception {
		return EmployeeRepository.getAll();
	}
	
	public static void insert(Employee entity) throws Exception {
		EmployeeRepository.insert(entity);
	}
	
	public static void update(Employee entity) throws Exception {
		EmployeeRepository.update(entity);
	}
	
	public static void delete(Employee entity) throws Exception {
		EmployeeRepository.delete(entity);
	}
}

