
/*
 *	Project AjTest
 *		AjTest
 *	Entity	Employee
 *		Employee
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class Employee {

//	Private Fields

	private int id; 
	private String employeeCode; 
	private String lastName; 
	private String firstName; 
	private Department department; 
	private List tasks; 
	private List employeeSkills; 


//	Default Constructor

	public Employee() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String value) {
		employeeCode = value;
	}
	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String value) {
		lastName = value;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String value) {
		firstName = value;
	}
	
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department value) {
		department = value;
	}
	
	public List getTasks() {
		return tasks;
	}

	public void setTasks(List value) {
		tasks = value;
	}
	
	public List getEmployeeSkills() {
		return employeeSkills;
	}

	public void setEmployeeSkills(List value) {
		employeeSkills = value;
	}

}

