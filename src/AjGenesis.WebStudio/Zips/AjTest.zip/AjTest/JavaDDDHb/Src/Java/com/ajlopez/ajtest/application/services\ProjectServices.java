
/*
 *	Project AjTest
 *		AjTest
 *	Services	ProjectServices
 *		Project
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class ProjectServices {
	public static Project getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Project entity = null;

		try {
			entity = ProjectManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = ProjectManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Project entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			ProjectManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Project entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			ProjectManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Project entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			ProjectManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

