
/*
 *	Project AjTest
 *		AjTest
 *	Entity	Customer
 *		Customer
 *	
 */

package com.ajlopez.ajtest.domain.entities;

import java.util.*;

public class Customer {

//	Private Fields

	private int id; 
	private String name; 
	private String address; 


//	Default Constructor

	public Customer() {
	}

//	Public Properties

	
	public int getId() {
		return id;
	}

	public void setId(int value) {
		id = value;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String value) {
		name = value;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String value) {
		address = value;
	}

}

