
/*
 *	Project AjTest
 *		AjTest
 *	Repository for Entity	Supplier
 *		Supplier
 *	
 */

package com.ajlopez.ajtest.domain.repositories;

import java.util.*;

import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class SupplierRepository {
	private static SupplierDAO dao = new SupplierDAO();

	public static void insert(Supplier entity) throws Exception {
		dao.insert(entity);
	}

	public static void update(Supplier entity) throws Exception {
		dao.update(entity);
	}

	public static void delete(Supplier entity) throws Exception {
		dao.delete(entity);
	}

	public static Supplier getById(int id) throws Exception {
		if (id==0)
			return null;
		return dao.getById(id);
	}

	public static List getAll() throws Exception {
		return dao.getAll();
	}
}

