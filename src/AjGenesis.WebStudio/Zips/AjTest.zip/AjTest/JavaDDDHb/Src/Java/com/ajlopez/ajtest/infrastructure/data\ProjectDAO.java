
/*
 *	Project	AjTest
 *		AjTest
 *	Project	Project
 *		Project
 *	
 */

package com.ajlopez.ajtest.infrastructure.data;

import java.util.*;
import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;

public class ProjectDAO {
	public Project getById(int id) throws Exception {
		return (Project) AjHibernate.getSession().get(Project.class,new Integer(id));
	}

	public List getAll() throws Exception {
		Query query = (AjHibernate.getSession()).createQuery("from com.ajlopez.ajtest.domain.entities.Project");
		return query.list();
	}

	public void insert(Project entity) throws Exception {
		AjHibernate.getSession().save(entity);
	}

	public void update(Project entity) throws Exception {
		AjHibernate.getSession().update(entity);
	}

	public void delete(Project entity) throws Exception {
		AjHibernate.getSession().delete(entity);
	}
}

