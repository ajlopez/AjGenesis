
/*
 *	Project AjTest
 *		AjTest
 *	Services	DepartmentServices
 *		Department
 *	
 */

package com.ajlopez.ajtest.application.services;

import java.util.List;

import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.managers.*;
import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class DepartmentServices {
	public static Department getById(int id) throws Exception {
		AjHibernate.beginTransaction();		

		Department entity = null;

		try {
			entity = DepartmentManager.getById(id);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entity;
	}

	public static List getAll() throws Exception {
		AjHibernate.beginTransaction();		

		List entities = null;

		try {
			entities = DepartmentManager.getAll();
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}

		return entities;
	}
	
	public static void insert(Department entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			DepartmentManager.insert(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void update(Department entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			DepartmentManager.update(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
	
	public static void delete(Department entity) throws Exception {
		AjHibernate.beginTransaction();		

		try {
			DepartmentManager.delete(entity);
		} catch (Exception ex) {
			AjHibernate.rollbackTransaction();
			throw ex;
		}
	}
}

