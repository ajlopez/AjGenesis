
/*
 *	Project	AjTest
 *		AjTest
 *	Customer	Customer
 *		Customer
 *	
 */

package com.ajlopez.ajtest.infrastructure.data;

import java.util.*;
import org.hibernate.*;

import com.ajlopez.ajtest.*;
import com.ajlopez.ajtest.domain.entities.*;

public class CustomerDAO {
	public Customer getById(int id) throws Exception {
		return (Customer) AjHibernate.getSession().get(Customer.class,new Integer(id));
	}

	public List getAll() throws Exception {
		Query query = (AjHibernate.getSession()).createQuery("from com.ajlopez.ajtest.domain.entities.Customer");
		return query.list();
	}

	public void insert(Customer entity) throws Exception {
		AjHibernate.getSession().save(entity);
	}

	public void update(Customer entity) throws Exception {
		AjHibernate.getSession().update(entity);
	}

	public void delete(Customer entity) throws Exception {
		AjHibernate.getSession().delete(entity);
	}
}

