
/*
 *	Project AjTest
 *		AjTest
 *	Repository for Entity	EmployeeSkill
 *		EmployeeSkill
 *	
 */

package com.ajlopez.ajtest.domain.repositories;

import java.util.*;

import com.ajlopez.ajtest.domain.entities.*;
import com.ajlopez.ajtest.infrastructure.data.*;

public class EmployeeSkillRepository {
	private static EmployeeSkillDAO dao = new EmployeeSkillDAO();

	public static void insert(EmployeeSkill entity) throws Exception {
		dao.insert(entity);
	}

	public static void update(EmployeeSkill entity) throws Exception {
		dao.update(entity);
	}

	public static void delete(EmployeeSkill entity) throws Exception {
		dao.delete(entity);
	}

	public static EmployeeSkill getById(int id) throws Exception {
		if (id==0)
			return null;
		return dao.getById(id);
	}

	public static List getAll() throws Exception {
		return dao.getAll();
	}
}

