
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Supplier
'		Supplier Entity
'	
'

Imports System.Collections.Generic

Imports AjFirstExample.Entities
Imports AjFirstExample.Business

Imports AjFramework.Data

Public Class SupplierService
	Private Shared mSupplierComponent as new SupplierComponent

	Public Shared Sub Insert(entity as Supplier)
		mSupplierComponent.Insert(entity)
	End Sub

	Public Shared Sub Update(entity as Supplier)
		mSupplierComponent.Update(entity)
	End Sub

	Public Shared Sub Delete(id as Integer)
		mSupplierComponent.Delete(id)
	End Sub

	Public Shared Function GetById(id as Integer) as Supplier
		return mSupplierComponent.GetById(id)
	End Function

	Public Shared Function GetAll() as List(Of Supplier)
		return mSupplierComponent.GetAll()
	End Function

	Public Shared Function GetList() as DataSet
		return mSupplierComponent.GetAllAsDs()
	End Function
End Class

