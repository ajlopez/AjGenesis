
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Supplier
'		Supplier Entity
'	
'

Public Class Supplier

'	Private Fields

	
	Private mId as Integer
	
	Private mName as String
	
	Private mAddress as String
	
	Private mNotes as String

'	Default Constructor

	Public Sub New()
	End Sub

'	Public Properties

	
	Public Property Id() as Integer
        Get
            Return mId
        End Get
        Set(ByVal Value As Integer)
            mId = Value
        End Set
	End Property
	
	Public Property Name() as String
        Get
            Return mName
        End Get
        Set(ByVal Value As String)
            mName = Value
        End Set
	End Property
	
	Public Property Address() as String
        Get
            Return mAddress
        End Get
        Set(ByVal Value As String)
            mAddress = Value
        End Set
	End Property
	
	Public Property Notes() as String
        Get
            Return mNotes
        End Get
        Set(ByVal Value As String)
            mNotes = Value
        End Set
	End Property

End Class

