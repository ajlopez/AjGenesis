
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Customer
'		Customer Entity
'	
'

Imports System.Collections.Generic

Imports AjFramework.Data

Imports AjFirstExample.Entities

Public Class CustomerData

	Public Sub Insert(entity as Customer)
		Dim dpid as new DataParameter

		dpid.Value = entity.Id

		DataService.ExecuteNonQuery("CustomerInsert", CommandType.StoredProcedure, _
			dpid, _
			entity.Name, _
			entity.Address, _
			entity.Notes _
		)

		entity.Id = dpid.Value
	End Sub

	Public Sub Update(entity as Customer)
		DataService.ExecuteNonQuery("CustomerUpdate", CommandType.StoredProcedure, _
			entity.Id, _
			entity.Name, _
			entity.Address, _
			entity.Notes _
		)
	End Sub

	Public Sub Delete(id as Integer)
		DataService.ExecuteNonQuery("CustomerDelete", CommandType.StoredProcedure, id)
	End Sub

	Public Function GetById(id as Integer) as Customer
		Dim reader as IDataReader = Nothing

		try
			reader = DataService.ExecuteReader("CustomerGetById", CommandType.StoredProcedure, id)

			if not reader.Read() then
				return Nothing
			end if
			
			Dim entity as Customer

			entity = Make(reader)

			return entity
		finally
			reader.Close()
		end try
	End Function

	Public Function GetAll() as List(of Customer)
		Dim reader as IDataReader
		Dim list as new List(of Customer)()

		reader = DataService.ExecuteReader("CustomerGetAll", CommandType.StoredProcedure )
		Dim entity as Customer
	
		while reader.Read()
			entity = Make(reader)
			list.Add(entity)
		end while
			
		reader.Close()

		return list
	End Function

	Public Function GetAllAsDs() as DataSet
		return DataService.ExecuteDataSet("CustomerGetAll", CommandType.StoredProcedure )
	End Function


	Private Function Make(reader as IDataReader) as Customer
		Dim entity as new Customer


		if reader("Id") is System.DbNull.Value then
			entity.Id = 0
		else
			entity.Id = CType(reader("Id"),Integer)
		end if
		if reader("Name") is System.DbNull.Value then
			entity.Name = Nothing
		else
			entity.Name = CType(reader("Name"),String)
		end if
		if reader("Address") is System.DbNull.Value then
			entity.Address = Nothing
		else
			entity.Address = CType(reader("Address"),String)
		end if
		if reader("Notes") is System.DbNull.Value then
			entity.Notes = Nothing
		else
			entity.Notes = CType(reader("Notes"),String)
		end if

		return entity
	End Function
End Class

