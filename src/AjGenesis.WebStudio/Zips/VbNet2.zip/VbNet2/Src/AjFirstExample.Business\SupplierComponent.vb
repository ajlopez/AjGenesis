
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Supplier
'		Supplier Entity
'	
'

Imports AjFirstExample.Entities
Imports AjFirstExample.Data

Public Class SupplierComponent
	Inherits SupplierComponentBase

	Public Overrides Sub Validate(entity as Supplier)
		MyBase.Validate(entity)
	End Sub

	Public Overrides Sub ValidateNew(entity as Supplier)
		MyBase.ValidateNew(entity)
	End Sub

	Public Overrides Sub ValidateDelete(entity as Supplier)
		MyBase.ValidateDelete(entity)
	End Sub
End Class

