
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


Imports AjFirstExample.Services
Imports AjFirstExample.Entities

Public Partial Class Admin_CustomersPage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            gvwData.DataSource = CustomerService.GetList
            gvwData.DataBind()
        End If
    End Sub

End Class
