
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


Imports AjFirstExample.Services
Imports AjFirstExample.Entities

Public Partial Class Admin_CustomerPage
    Inherits System.Web.UI.Page

    Public Entity As Customer

    Public Property IdEntity() As Integer
        Get
            Return DirectCast(ViewState("IdEntity"), Integer)
        End Get
        Set(ByVal Value As Integer)
            ViewState("IdEntity") = Value
        End Set
    End Property



    Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
			IdEntity = CInt(Request("Id"))
			Entity = CustomerService.GetById(IdEntity)
            	DataBind()
        End If
    End Sub

End Class
