
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


Partial Class Admin_DefaultPage
    Inherits System.Web.UI.Page

End Class
