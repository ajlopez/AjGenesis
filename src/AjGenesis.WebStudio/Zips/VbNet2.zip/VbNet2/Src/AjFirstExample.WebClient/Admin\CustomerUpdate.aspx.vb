
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


Imports System
Imports System.Data

Imports AjFirstExample.Services
Imports AjFirstExample.Entities

Public Partial Class Admin_CustomerUpdatePage
    Inherits System.Web.UI.Page

    Public Entity As Customer

    Public Property IdEntity() As Integer
        Get
            Return DirectCast(ViewState("IdEntity"), Integer)
        End Get
        Set(ByVal Value As Integer)
            ViewState("IdEntity") = Value
        End Set
    End Property



    Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
			If Request("Id") Is Nothing then
				IdEntity = 0
				Entity = new Customer
			else
				IdEntity = CInt(Request("Id"))
				Entity = CustomerService.GetById(IdEntity)
			End If
            	DataBind()

			if IdEntity>0 then
			else
			end if
        End If
    End Sub

    Private Function FormValidate() As Boolean
        Return True
    End Function

    Private Sub Update()
		if IdEntity>0 then
			Entity = CustomerService.GetById(IdEntity)
		else
			Entity = New Customer()
        end if

        
		Entity.Name = txtName.Text
        
		Entity.Address = txtAddress.Text
        
		Entity.Notes = txtNotes.Text
        

        If IdEntity = 0 Then
            CustomerService.Insert(Entity)
        Else
            CustomerService.Update(Entity)
        End If
    End Sub

    Private Sub btnAccept_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAccept.Click
        If Not IsValid Then
            Return
        End If

        Try
            If FormValidate() Then
                Update()
		        If IdEntity = 0 Then
		            Server.Transfer("Customers.aspx")
				Else
					Server.Transfer("Customer.aspx?Id=" & IdEntity)
		        End If
            End If
        Catch Ex As Exception
            lblMensaje.Visible = True
            lblMensaje.Text = Ex.Message
        End Try
    End Sub
End Class
