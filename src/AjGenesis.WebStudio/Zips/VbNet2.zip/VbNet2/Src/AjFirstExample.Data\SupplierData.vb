
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Supplier
'		Supplier Entity
'	
'

Imports System.Collections.Generic

Imports AjFramework.Data

Imports AjFirstExample.Entities

Public Class SupplierData

	Public Sub Insert(entity as Supplier)
		Dim dpid as new DataParameter

		dpid.Value = entity.Id

		DataService.ExecuteNonQuery("SupplierInsert", CommandType.StoredProcedure, _
			dpid, _
			entity.Name, _
			entity.Address, _
			entity.Notes _
		)

		entity.Id = dpid.Value
	End Sub

	Public Sub Update(entity as Supplier)
		DataService.ExecuteNonQuery("SupplierUpdate", CommandType.StoredProcedure, _
			entity.Id, _
			entity.Name, _
			entity.Address, _
			entity.Notes _
		)
	End Sub

	Public Sub Delete(id as Integer)
		DataService.ExecuteNonQuery("SupplierDelete", CommandType.StoredProcedure, id)
	End Sub

	Public Function GetById(id as Integer) as Supplier
		Dim reader as IDataReader = Nothing

		try
			reader = DataService.ExecuteReader("SupplierGetById", CommandType.StoredProcedure, id)

			if not reader.Read() then
				return Nothing
			end if
			
			Dim entity as Supplier

			entity = Make(reader)

			return entity
		finally
			reader.Close()
		end try
	End Function

	Public Function GetAll() as List(of Supplier)
		Dim reader as IDataReader
		Dim list as new List(of Supplier)()

		reader = DataService.ExecuteReader("SupplierGetAll", CommandType.StoredProcedure )
		Dim entity as Supplier
	
		while reader.Read()
			entity = Make(reader)
			list.Add(entity)
		end while
			
		reader.Close()

		return list
	End Function

	Public Function GetAllAsDs() as DataSet
		return DataService.ExecuteDataSet("SupplierGetAll", CommandType.StoredProcedure )
	End Function


	Private Function Make(reader as IDataReader) as Supplier
		Dim entity as new Supplier


		if reader("Id") is System.DbNull.Value then
			entity.Id = 0
		else
			entity.Id = CType(reader("Id"),Integer)
		end if
		if reader("Name") is System.DbNull.Value then
			entity.Name = Nothing
		else
			entity.Name = CType(reader("Name"),String)
		end if
		if reader("Address") is System.DbNull.Value then
			entity.Address = Nothing
		else
			entity.Address = CType(reader("Address"),String)
		end if
		if reader("Notes") is System.DbNull.Value then
			entity.Notes = Nothing
		else
			entity.Notes = CType(reader("Notes"),String)
		end if

		return entity
	End Function
End Class

