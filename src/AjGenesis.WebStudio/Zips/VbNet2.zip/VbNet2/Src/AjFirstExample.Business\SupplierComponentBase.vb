
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Supplier
'		Supplier Entity
'	
'

Imports System.Collections.Generic

Imports AjFirstExample.Entities
Imports AjFirstExample.Data

Public Class SupplierComponentBase
	Protected Shared mSupplierData as new SupplierData

	Public Overridable Sub Validate(entity as Supplier)
	End Sub

	Public Overridable Sub ValidateNew(entity as Supplier)
	End Sub

	Public Overridable Sub ValidateDelete(entity as Supplier)

	End Sub

	Public Sub Insert(entity as Supplier)
		ValidateNew(entity)
		mSupplierData.Insert(entity)
	End Sub

	Public Sub Update(entity as Supplier)
		Validate(entity)
		mSupplierData.Update(entity)
	End Sub

	Public Sub Delete(id as Integer)
		ValidateDelete(GetById(id))
		mSupplierData.Delete(id)
	End Sub

	Public Function GetById(id as Integer) as Supplier
		return mSupplierData.GetById(id)
	End Function

	Public Function GetAll() as List(of Supplier)
		return mSupplierData.GetAll()
	End Function

	Public Function GetAllAsDs() as DataSet
		return mSupplierData.GetAllAsDs()
	End Function
End Class

