
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Customer
'		Customer Entity
'	
'

Imports AjFirstExample.Entities
Imports AjFirstExample.Data

Public Class CustomerComponent
	Inherits CustomerComponentBase

	Public Overrides Sub Validate(entity as Customer)
		MyBase.Validate(entity)
	End Sub

	Public Overrides Sub ValidateNew(entity as Customer)
		MyBase.ValidateNew(entity)
	End Sub

	Public Overrides Sub ValidateDelete(entity as Customer)
		MyBase.ValidateDelete(entity)
	End Sub
End Class

