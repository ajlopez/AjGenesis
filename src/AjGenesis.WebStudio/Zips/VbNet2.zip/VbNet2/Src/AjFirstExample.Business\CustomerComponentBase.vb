
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Customer
'		Customer Entity
'	
'

Imports System.Collections.Generic

Imports AjFirstExample.Entities
Imports AjFirstExample.Data

Public Class CustomerComponentBase
	Protected Shared mCustomerData as new CustomerData

	Public Overridable Sub Validate(entity as Customer)
	End Sub

	Public Overridable Sub ValidateNew(entity as Customer)
	End Sub

	Public Overridable Sub ValidateDelete(entity as Customer)

	End Sub

	Public Sub Insert(entity as Customer)
		ValidateNew(entity)
		mCustomerData.Insert(entity)
	End Sub

	Public Sub Update(entity as Customer)
		Validate(entity)
		mCustomerData.Update(entity)
	End Sub

	Public Sub Delete(id as Integer)
		ValidateDelete(GetById(id))
		mCustomerData.Delete(id)
	End Sub

	Public Function GetById(id as Integer) as Customer
		return mCustomerData.GetById(id)
	End Function

	Public Function GetAll() as List(of Customer)
		return mCustomerData.GetAll()
	End Function

	Public Function GetAllAsDs() as DataSet
		return mCustomerData.GetAllAsDs()
	End Function
End Class

