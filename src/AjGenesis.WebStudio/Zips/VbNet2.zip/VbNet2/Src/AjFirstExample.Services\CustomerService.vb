
'
' File generated using AjGenesis
' http://www.ajlopez.com/ajgenesis
' http://www.ajlopez.net/ajgenesis
' Open Source Code Generation Engine
'


'
'	Project AjFirstExample
'		First Example using AjGenesis
'	Entity	Customer
'		Customer Entity
'	
'

Imports System.Collections.Generic

Imports AjFirstExample.Entities
Imports AjFirstExample.Business

Imports AjFramework.Data

Public Class CustomerService
	Private Shared mCustomerComponent as new CustomerComponent

	Public Shared Sub Insert(entity as Customer)
		mCustomerComponent.Insert(entity)
	End Sub

	Public Shared Sub Update(entity as Customer)
		mCustomerComponent.Update(entity)
	End Sub

	Public Shared Sub Delete(id as Integer)
		mCustomerComponent.Delete(id)
	End Sub

	Public Shared Function GetById(id as Integer) as Customer
		return mCustomerComponent.GetById(id)
	End Function

	Public Shared Function GetAll() as List(Of Customer)
		return mCustomerComponent.GetAll()
	End Function

	Public Shared Function GetList() as DataSet
		return mCustomerComponent.GetAllAsDs()
	End Function
End Class

