using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

/// <summary>
///		Summary description for Header.
/// </summary>
public partial class Controls_Footer : System.Web.UI.UserControl
{
	private void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
	}
}

