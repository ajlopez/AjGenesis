
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using AjFirstExample.Application;
using AjFirstExample.Domain;

/// <summary>
/// Summary description for _Default.
/// </summary>
public partial class Admin_CustomerUpdatePage : System.Web.UI.Page
{
	public Customer Entity;

	public int IdEntity {
		get {
			return (int) ViewState["IdEntity"];
		}
		set {
			ViewState["IdEntity"] = value;
		}
	}



	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack) {
			if (Request["Id"]==null) {
				IdEntity = 0;
				Entity = new Customer();
			}
			else {
				IdEntity = Convert.ToInt32(Request["Id"]);
				Entity = CustomerService.GetCustomerById(IdEntity);
			}
           	DataBind();

			if (IdEntity>0) {
			}
			else {
			}
		}
	}

	private bool FormValidate() {
		return true;
	}


	private void Update() {		
		CustomerInfo entity = new CustomerInfo();

        
		entity.Name = txtName.Text;
        
		entity.Address = txtAddress.Text;
        
		entity.Notes = txtNotes.Text;
        

     	if (IdEntity == 0)
			CustomerService.NewCustomer(entity);
		else
			CustomerService.UpdateCustomer(entity);
	}

   protected void btnAccept_Click(object sender,EventArgs e) {
		if (!IsValid)
			return;

		try {
			if (FormValidate()) {
				Update();
				if (IdEntity==0)
	            Server.Transfer("Customers.aspx");
				else
					Server.Transfer("Customer.aspx?Id=" + IdEntity);
			}
		}
      catch (Exception ex) {
         lblMensaje.Visible = true;
         lblMensaje.Text = ex.Message;
		}
	}
}

