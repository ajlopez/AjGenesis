
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 */

using System;
using System.Collections;

namespace AjFirstExample.Domain {

	public class Supplier  {

//	Private Fields

	
		private int id;
	
		private string name;
	
		private string address;
	
		private string notes;



//	Default Constructor

		public Supplier() {
		}

//	Factory Methods

		public static Supplier CreateSupplier(
			string name ,
			string address ,
			string notes 
			) {
			Supplier supplier;

			supplier = new Supplier();

			supplier.Name = name;
			supplier.Address = address;
			supplier.Notes = notes;

			return supplier;
		}

//	Public Properties

	
		public virtual int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public virtual string Name
		{
			get {
				return name;
			}
			set {
				name = value;
			}
		}

	
		public virtual string Address
		{
			get {
				return address;
			}
			set {
				address = value;
			}
		}

	
		public virtual string Notes
		{
			get {
				return notes;
			}
			set {
				notes = value;
			}
		}



	}

}
