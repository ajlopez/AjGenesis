
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;
using System.Collections;

using AjNHibernate;

namespace AjFirstExample.Domain {

	public class SupplierRepository {
		public static void Add(Supplier entity) {
			Repository.Current.SaveObject(entity);
		}

		public static void Update(Supplier entity) {
			Repository.Current.UpdateObject(entity);
		}

		public static void Remove(Supplier entity) {
			Repository.Current.DeleteObject(entity);
		}

		public static Supplier GetById(int id) {
			if (id==0)
				return null;
		
			return (Supplier) Repository.Current.GetObjectById(typeof(Supplier),id);
		}

		public static IList GetAll() {
			return Repository.Current.GetAll(typeof(Supplier));
		}
	}
}

