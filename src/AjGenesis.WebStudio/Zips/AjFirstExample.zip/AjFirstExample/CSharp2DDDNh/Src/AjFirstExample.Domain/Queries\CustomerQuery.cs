
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

using System;

namespace AjFirstExample.Entities {

	public class CustomerQuery {

	
		public int Id;
	
		public string Name;
	
		public string Address;
	
		public string Notes;

	}
}

