
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;

namespace AjFirstExample.Domain {

	public class CustomerManager {

		public static void AddNew(Customer entity ) {

			Add(entity);
		}

		public static void Add(Customer entity) {
			// TODO: Apply Specifications

			CustomerRepository.Add(entity);
		}

		public static void Update(Customer entity) {
			// TODO: Apply Specifications

			CustomerRepository.Update(entity);
		}

		public static void Delete(Customer entity) {
			// TODO: Apply Specifications


			CustomerRepository.Remove(entity);
		}
	}
}

