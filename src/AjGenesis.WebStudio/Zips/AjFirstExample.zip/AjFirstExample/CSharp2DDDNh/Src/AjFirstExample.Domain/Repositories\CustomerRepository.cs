
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;
using System.Collections;

using AjNHibernate;

namespace AjFirstExample.Domain {

	public class CustomerRepository {
		public static void Add(Customer entity) {
			Repository.Current.SaveObject(entity);
		}

		public static void Update(Customer entity) {
			Repository.Current.UpdateObject(entity);
		}

		public static void Remove(Customer entity) {
			Repository.Current.DeleteObject(entity);
		}

		public static Customer GetById(int id) {
			if (id==0)
				return null;
		
			return (Customer) Repository.Current.GetObjectById(typeof(Customer),id);
		}

		public static IList GetAll() {
			return Repository.Current.GetAll(typeof(Customer));
		}
	}
}

