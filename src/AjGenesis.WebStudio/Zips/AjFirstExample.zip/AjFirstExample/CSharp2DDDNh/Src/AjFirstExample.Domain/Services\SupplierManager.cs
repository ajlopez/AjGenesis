
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;

namespace AjFirstExample.Domain {

	public class SupplierManager {

		public static void AddNew(Supplier entity ) {

			Add(entity);
		}

		public static void Add(Supplier entity) {
			// TODO: Apply Specifications

			SupplierRepository.Add(entity);
		}

		public static void Update(Supplier entity) {
			// TODO: Apply Specifications

			SupplierRepository.Update(entity);
		}

		public static void Delete(Supplier entity) {
			// TODO: Apply Specifications


			SupplierRepository.Remove(entity);
		}
	}
}

