
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 */

using System;
using System.Collections;

namespace AjFirstExample.Domain {

	public class Customer  {

//	Private Fields

	
		private int id;
	
		private string name;
	
		private string address;
	
		private string notes;



//	Default Constructor

		public Customer() {
		}

//	Factory Methods

		public static Customer CreateCustomer(
			string name ,
			string address ,
			string notes 
			) {
			Customer customer;

			customer = new Customer();

			customer.Name = name;
			customer.Address = address;
			customer.Notes = notes;

			return customer;
		}

//	Public Properties

	
		public virtual int Id
		{
			get {
				return id;
			}
			set {
				id = value;
			}
		}

	
		public virtual string Name
		{
			get {
				return name;
			}
			set {
				name = value;
			}
		}

	
		public virtual string Address
		{
			get {
				return address;
			}
			set {
				address = value;
			}
		}

	
		public virtual string Notes
		{
			get {
				return notes;
			}
			set {
				notes = value;
			}
		}



	}

}
