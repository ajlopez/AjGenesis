
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;
using System.Collections;

using AjFirstExample.Domain;

namespace AjFirstExample.Application {

	public class CustomerService {

		// New Entity in the System, using a Domain Object

		public static void NewCustomer(Customer entity) {
			CustomerManager.AddNew(entity);
		}

		// New Entity in the System, using a Message

		public static void NewCustomer(CustomerInfo entityinfo) {
			Customer entity;

			entity = Customer.CreateCustomer( 
			entityinfo.Name 
, 			entityinfo.Address 
, 			entityinfo.Notes 
			);

			CustomerManager.Add(entity);
		}

		// Update Entity

		public static void UpdateCustomer(Customer entity) {
			CustomerManager.Update(entity);
		}

		// Update Entity using a Message

		public static void UpdateCustomer(CustomerInfo entityinfo) {
			Customer entity;

			entity = CustomerRepository.GetById(entityinfo.Id);

			entity.Id = entityinfo.Id;
			entity.Name = entityinfo.Name;
			entity.Address = entityinfo.Address;
			entity.Notes = entityinfo.Notes;

			CustomerManager.Update(entity);
		}

		public static void DeleteCustomer(int id) {
			Customer entity;

			entity = CustomerRepository.GetById(id);

			CustomerManager.Delete(entity);
		}

		public static Domain.Customer GetCustomerById(int id) {
			return CustomerRepository.GetById(id);
		}

		public static IList GetCustomers() {
			return CustomerRepository.GetAll();
		}
	}
}

