
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;

namespace AjFirstExample.Application {
	public class SupplierInfo {

		//	Private Fields

	
		private int id; 	
		private string name; 	
		private string address; 	
		private string notes; 
		//	Factory Methods

		public static SupplierInfo Create(
			string name ,
			string address ,
			string notes 
		) {

			SupplierInfo supplier;

			supplier = new SupplierInfo();

			supplier.Name = name;
			supplier.Address = address;
			supplier.Notes = notes;

			return supplier;
		}

		//	Public Properties

	
		public int Id {
			get {
				return id;
			}
			set {
				id = value;
			}
		}
	
		public string Name {
			get {
				return name;
			}
			set {
				name = value;
			}
		}
	
		public string Address {
			get {
				return address;
			}
			set {
				address = value;
			}
		}
	
		public string Notes {
			get {
				return notes;
			}
			set {
				notes = value;
			}
		}
	}
}

