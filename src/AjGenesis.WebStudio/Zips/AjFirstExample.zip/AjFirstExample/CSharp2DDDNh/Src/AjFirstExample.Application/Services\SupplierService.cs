
/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Supplier
 *		Supplier Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;
using System.Collections;

using AjFirstExample.Domain;

namespace AjFirstExample.Application {

	public class SupplierService {

		// New Entity in the System, using a Domain Object

		public static void NewSupplier(Supplier entity) {
			SupplierManager.AddNew(entity);
		}

		// New Entity in the System, using a Message

		public static void NewSupplier(SupplierInfo entityinfo) {
			Supplier entity;

			entity = Supplier.CreateSupplier( 
			entityinfo.Name 
, 			entityinfo.Address 
, 			entityinfo.Notes 
			);

			SupplierManager.Add(entity);
		}

		// Update Entity

		public static void UpdateSupplier(Supplier entity) {
			SupplierManager.Update(entity);
		}

		// Update Entity using a Message

		public static void UpdateSupplier(SupplierInfo entityinfo) {
			Supplier entity;

			entity = SupplierRepository.GetById(entityinfo.Id);

			entity.Id = entityinfo.Id;
			entity.Name = entityinfo.Name;
			entity.Address = entityinfo.Address;
			entity.Notes = entityinfo.Notes;

			SupplierManager.Update(entity);
		}

		public static void DeleteSupplier(int id) {
			Supplier entity;

			entity = SupplierRepository.GetById(id);

			SupplierManager.Delete(entity);
		}

		public static Domain.Supplier GetSupplierById(int id) {
			return SupplierRepository.GetById(id);
		}

		public static IList GetSuppliers() {
			return SupplierRepository.GetAll();
		}
	}
}

