
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


/*
 *	Project AjFirstExample
 *		First Example using AjGenesis
 *	Entity	Customer
 *		Customer Entity
 *	
 *	Note: This implementation is too much oriented to CRUD operations
 *	
 */

using System;

namespace AjFirstExample.Application {
	public class CustomerInfo {

		//	Private Fields

	
		private int id; 	
		private string name; 	
		private string address; 	
		private string notes; 
		//	Factory Methods

		public static CustomerInfo Create(
			string name ,
			string address ,
			string notes 
		) {

			CustomerInfo customer;

			customer = new CustomerInfo();

			customer.Name = name;
			customer.Address = address;
			customer.Notes = notes;

			return customer;
		}

		//	Public Properties

	
		public int Id {
			get {
				return id;
			}
			set {
				id = value;
			}
		}
	
		public string Name {
			get {
				return name;
			}
			set {
				name = value;
			}
		}
	
		public string Address {
			get {
				return address;
			}
			set {
				address = value;
			}
		}
	
		public string Notes {
			get {
				return notes;
			}
			set {
				notes = value;
			}
		}
	}
}

