
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;

using NHibernate;
using NHibernate.Cfg;

namespace AjNHibernate {

	public class SessionFactory {
		private static SessionFactory session = new SessionFactory();
		private static Configuration nhconfiguration;
		private static ISessionFactory nhsessionfactory;

		public SessionFactory() {
			RegisterClasses();
		}
	
		private void RegisterClasses() {
			nhconfiguration = new Configuration();
			nhconfiguration.AddAssembly("AjFirstExample.Domain");
			nhsessionfactory = nhconfiguration.BuildSessionFactory();
		}

		public static SessionFactory Instance {
			get {
				return session;
			}
		}

		public ISession GetSession() {
			return nhsessionfactory.OpenSession();
		}

		public ISessionFactory GetNHibernateFactory() {
			return nhsessionfactory;
		}
	}
}
