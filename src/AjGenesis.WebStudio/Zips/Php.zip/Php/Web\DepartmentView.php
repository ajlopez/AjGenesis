<?
	$Page->Title = 'Department';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/DepartmentFunctions.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');

	DbConnect();
	
	SessionPut('DepartmentLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = DepartmentGetById($Id);
	$Name = $rs['Name'];


	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="DepartmentList.php">Departments</a>
&nbsp;
&nbsp;
<a href="DepartmentForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="DepartmentDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Name",$Name);
?>
</table>


</center>

<center>
<h2>Employees</h2>

<?
	$rsEmployees = EmployeeGetByDepartment($Id);

	$titles = array('Id', 'Name', 'Address', 'Notes');

	TableOpen($titles,"98%");

	while ($reg=DbNextRow($rsEmployees)) {
		RowOpen();
		DatumLinkGenerate($reg['Id'],"EmployeeView.php?Id=".$reg['Id']);
		DatumGenerate($reg['Name']);
		DatumGenerate($reg['Address']);
		DatumGenerate($reg['Notes']);
		RowClose();
	}


	TableClose();	

	DbFreeResult($rsEmployees);
?>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
