<?
	$Page->Title = 'Actualiza Employee';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');

	DbConnect();
	
	if (!ErrorHas() && isset($Id)) {
		$rs = EmployeeGetById($Id);
		$Name = $rs['Name'];
		$IdDepartment = $rs['IdDepartment'];
		$Address = $rs['Address'];
		$Notes = $rs['Notes'];

		$IsNew = 0;
	}	
	else if (isset($Id))
		$IsNew = 0;
	else {
		$Page->Title = "Nuevo Employee";
		$IsNew = 1;
	}

	$rsIdDepartment = TranslateQuery("$Cfg[SqlPrefix]departments","Name as Name");

	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeList.php">Employees</a>
&nbsp;
&nbsp;
<?
	if (!$IsNew) {
?>
<a href="EmployeeView.php?Id=<? echo $Id; ?>">Employee</a>
&nbsp;
&nbsp;
<?
	}
?>
</p>


<?
	ErrorRender();
?>

<p>

<form action="EmployeeUpdate.php" method=post>

<table cellspacing=1 cellpadding=2 class="form">
<?
	if (!$IsNew)
		FieldStaticGenerate("Id",$Id);

	FieldTextGenerate("Name","Name",$Name,30,False);
	FieldComboRsGenerate("IdDepartment","Department",$rsIdDepartment,$IdDepartment,"Id","Name",false,False);
	FieldTextGenerate("Address","Address",$Address,30,False);
	FieldTextGenerate("Notes","Notes",$Notes,30,False);

	FieldOkGenerate();
?>
</table>

<?
	if (!$IsNew)
		FieldIdGenerate($Id);
?>

</form>

</center>

<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
