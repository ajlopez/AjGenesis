<?
$Cfg['SiteName']='AjSecondExample';
//$Cfg['SiteLogo']='AjSecondExample.gif';
$Cfg['SiteDescription']='Second Example using AjGenesis';

$Cfg['SqlType']='MySql';
$Cfg['SqlHost']='localhost';
$Cfg['SqlBase']='ajsecondexample';
$Cfg['SqlUser']='root';
$Cfg['SqlPassword']='';
$Cfg['SqlPrefix']='';
?>
