<?
	$Page->Title = 'Employee';

	include_once($Page->Prefix.'ajfwk/Database.inc.php');
	include_once($Page->Prefix.'ajfwk/Errors.inc.php');
	include_once($Page->Prefix.'ajfwk/Pages.inc.php');
	include_once($Page->Prefix.'ajfwk/Session.inc.php');
	include_once($Page->Prefix.'ajfwk/Forms.inc.php');
	include_once($Page->Prefix.'ajfwk/Tables.inc.php');
	include_once($Page->Prefix.'ajfwk/Translations.inc.php');

	include_once($Page->Prefix.'includes/Enumerations.inc.php');
	include_once($Page->Prefix.'includes/EmployeeFunctions.inc.php');

	DbConnect();
	
	SessionPut('EmployeeLink',PageCurrent());


	if (!isset($Id))
		PageExit();

	$rs = EmployeeGetById($Id);
	$Name = $rs['Name'];
	$IdDepartment = $rs['IdDepartment'];
	$Address = $rs['Address'];
	$Notes = $rs['Notes'];

	$TranslationIdDepartment = "<a href='DepartmentView.php?Id=".$IdDepartment. "'>".TranslateDescription("$Cfg[SqlPrefix]departments",$IdDepartment,"Name","Id")."</a>";

	include_once($Page->Prefix.'includes/Header.inc.php');
?>

<center>

<p>
<a href="EmployeeList.php">Employees</a>
&nbsp;
&nbsp;
<a href="EmployeeForm.php?Id=<? echo $Id; ?>">Update</a>
&nbsp;
&nbsp;
<a href="EmployeeDelete.php?Id=<? echo $Id; ?>">Delete</a>
</p>

<p>

<table cellspacing=1 cellpadding=2 class="form" width="80%">
<?
	FieldStaticGenerate("Id",$Id);
	FieldStaticGenerate("Name",$Name);
	FieldStaticGenerate("Department",$TranslationIdDepartment);
	FieldStaticGenerate("Address",$Address);
	FieldStaticGenerate("Notes",$Notes);
?>
</table>


</center>


<?
	DbDisconnect();
	include_once($Page->Prefix.'includes/Footer.inc.php');
?>
