
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using AjFirstExample.Gateways;
using AjFirstExample.Services.Contracts;

public partial class Admin_CustomerUpdatePage : System.Web.UI.Page
{
	public Customer Entity;

	public string IdEntity {
		get {
			return (string) ViewState["IdEntity"];
		}
		set {
			ViewState["IdEntity"] = value;
		}
	}



	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack) {
			CustomersServiceClient service = new CustomersServiceClient();

			if (Request["Id"]==null) {
				IdEntity = null;
				Entity = new Customer();
				Title = "New Customer";
			}
			else {
				IdEntity = Request["Id"];
				Entity = service.GetCustomer(new Guid(IdEntity));
				Title = "Update Customer";
			}
           	DataBind();

			if (IdEntity!=null) {
			}
			else {
			}
		}
	}

	private bool FormValidate() {
		return true;
	}


	private void Update() {
		CustomersServiceClient service = new CustomersServiceClient();

		if (IdEntity!=null)
			Entity = service.GetCustomer(new Guid(IdEntity));
		else
			Entity = new Customer();

        
		Entity.Name = txtName.Text;
        
		Entity.Address = txtAddress.Text;
        
		Entity.Notes = txtNotes.Text;
        
     	if (IdEntity == null)
			service.Add(Entity);
		else
			service.Update(Entity);
	}

   protected void btnAccept_Click(object sender,EventArgs e) {
		if (!IsValid)
			return;

		try {
			if (FormValidate()) {
				Update();
				if (IdEntity==null)
	            Server.Transfer("Customers.aspx");
				else
					Server.Transfer("Customer.aspx?Id=" + IdEntity);
			}
		}
      catch (Exception ex) {
         lblMensaje.Visible = true;
         lblMensaje.Text = ex.Message;
		}
	}
}

