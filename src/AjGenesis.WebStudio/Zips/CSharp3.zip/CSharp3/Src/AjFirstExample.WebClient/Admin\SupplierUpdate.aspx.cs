
/*
* File generated using AjGenesis
* http://www.ajlopez.com/ajgenesis
* http://www.ajlopez.net/ajgenesis
* Open Source Code Generation Engine
*/


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using AjFirstExample.Gateways;
using AjFirstExample.Services.Contracts;

public partial class Admin_SupplierUpdatePage : System.Web.UI.Page
{
	public Supplier Entity;

	public string IdEntity {
		get {
			return (string) ViewState["IdEntity"];
		}
		set {
			ViewState["IdEntity"] = value;
		}
	}



	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack) {
			SuppliersServiceClient service = new SuppliersServiceClient();

			if (Request["Id"]==null) {
				IdEntity = null;
				Entity = new Supplier();
				Title = "New Supplier";
			}
			else {
				IdEntity = Request["Id"];
				Entity = service.GetSupplier(new Guid(IdEntity));
				Title = "Update Supplier";
			}
           	DataBind();

			if (IdEntity!=null) {
			}
			else {
			}
		}
	}

	private bool FormValidate() {
		return true;
	}


	private void Update() {
		SuppliersServiceClient service = new SuppliersServiceClient();

		if (IdEntity!=null)
			Entity = service.GetSupplier(new Guid(IdEntity));
		else
			Entity = new Supplier();

        
		Entity.Name = txtName.Text;
        
		Entity.Address = txtAddress.Text;
        
		Entity.Notes = txtNotes.Text;
        
     	if (IdEntity == null)
			service.Add(Entity);
		else
			service.Update(Entity);
	}

   protected void btnAccept_Click(object sender,EventArgs e) {
		if (!IsValid)
			return;

		try {
			if (FormValidate()) {
				Update();
				if (IdEntity==null)
	            Server.Transfer("Suppliers.aspx");
				else
					Server.Transfer("Supplier.aspx?Id=" + IdEntity);
			}
		}
      catch (Exception ex) {
         lblMensaje.Visible = true;
         lblMensaje.Text = ex.Message;
		}
	}
}

