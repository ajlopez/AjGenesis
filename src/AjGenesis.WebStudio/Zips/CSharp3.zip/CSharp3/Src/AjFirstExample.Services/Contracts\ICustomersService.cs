namespace AjFirstExample.Services.Contracts
{
	using System;
	using System.Data;
	using System.Collections.Generic;
	using System.ServiceModel;

	[ServiceContract]
	public interface ICustomersService
	{
		[OperationContract]
		void Add(Customer customer);
		[OperationContract]
		void Update(Customer customer);
		[OperationContract]
		void Delete(Guid id);
		[OperationContract]
		Customer[] GetCustomers();
		[OperationContract]
		Customer GetCustomer(Guid id);

	}
}
