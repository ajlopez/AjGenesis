namespace AjFirstExample.Services.Contracts
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    public class Customer
    {
	
		[DataMember]
       public Guid Id { get; set; }
	
		[DataMember]
       public string Name { get; set; }
	
		[DataMember]
       public string Address { get; set; }
	
		[DataMember]
       public string Notes { get; set; }
    }
}
