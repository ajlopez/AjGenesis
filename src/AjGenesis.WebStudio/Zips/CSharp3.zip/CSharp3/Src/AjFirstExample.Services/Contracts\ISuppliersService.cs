namespace AjFirstExample.Services.Contracts
{
	using System;
	using System.Data;
	using System.Collections.Generic;
	using System.ServiceModel;

	[ServiceContract]
	public interface ISuppliersService
	{
		[OperationContract]
		void Add(Supplier supplier);
		[OperationContract]
		void Update(Supplier supplier);
		[OperationContract]
		void Delete(Guid id);
		[OperationContract]
		Supplier[] GetSuppliers();
		[OperationContract]
		Supplier GetSupplier(Guid id);

	}
}
