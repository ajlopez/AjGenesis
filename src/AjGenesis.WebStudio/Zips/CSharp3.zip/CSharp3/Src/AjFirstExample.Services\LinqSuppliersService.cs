namespace AjFirstExample.Services
{
	using System;
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.Transactions;
	using System.Linq;
	using System.Data;
	using Contracts;

	public class LinqSuppliersService : ISuppliersService
	{
		AjFirstExample.Data.ISupplierStore store;

		public LinqSuppliersService(AjFirstExample.Data.ISupplierStore store)
		{
			this.store = store;
		}

		public LinqSuppliersService()
            : this(new AjFirstExample.Data.SupplierStore())
		{
		}

       public void Add(Supplier supplier)
		{
            using (TransactionScope scope = new TransactionScope())
            {
                AjFirstExample.Data.Supplier dataentity = new AjFirstExample.Data.Supplier()
                {
						Id = Guid.NewGuid() ,
						Name = supplier.Name,
						Address = supplier.Address,
						Notes = supplier.Notes
                };
                this.store.Add(dataentity);
                scope.Complete();
            }
		}

       public void Update(Supplier supplier)
		{
            using (TransactionScope scope = new TransactionScope())
            {
                AjFirstExample.Data.Supplier dataentity = new AjFirstExample.Data.Supplier()
                {
						Id = supplier.Id,
						Name = supplier.Name,
						Address = supplier.Address,
						Notes = supplier.Notes
                };
                this.store.Update(dataentity);
                scope.Complete();
            }
		}

       public void Delete(Guid id)
		{
			throw new NotImplementedException();
		}

       public Supplier[] GetSuppliers()
		{
			AjFirstExample.Data.Supplier[] suppliers = this.store.GetSuppliers();

			List<Supplier> suppliersModel = new List<Supplier>();

          foreach (AjFirstExample.Data.Supplier supplier in suppliers)
          {                
				Supplier result = new Supplier()
				{
					Id = supplier.Id,
					Name = supplier.Name,
					Address = supplier.Address,
					Notes = supplier.Notes
				};

				suppliersModel.Add(result);
			}

			return suppliersModel.ToArray();
		}


       public Supplier GetSupplier(Guid id) 
		{
			AjFirstExample.Data.Supplier supplier = store.GetSupplier(id);

			Supplier entity = new Supplier
			{
				Id = supplier.Id,
				Name = supplier.Name,
				Address = supplier.Address,
				Notes = supplier.Notes
			};

			return entity;
		}

   }
}

