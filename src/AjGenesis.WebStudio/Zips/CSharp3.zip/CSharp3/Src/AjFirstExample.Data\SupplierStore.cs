namespace AjFirstExample.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AjFirstExample.Data;

    public class SupplierStore: ISupplierStore
    {
        
        public void Add(Supplier supplier)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                var entity = new Supplier()
                {
					Id = supplier.Id, 
					Name = supplier.Name, 
					Address = supplier.Address, 
					Notes = supplier.Notes 
                };

                context.Suppliers.InsertOnSubmit(entity);
                context.SubmitChanges();
            }
        }

        public Supplier[] GetSuppliers()
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                var entities = context.Suppliers.OrderBy( entity => entity.Id);
                
                return entities.ToArray();
            }
        }

        public Supplier GetSupplier(Guid id)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                Supplier supplier  = context.Suppliers.SingleOrDefault(r => r.Id == id);
                return supplier;
            }
        }
		
        public void Update(Supplier supplier)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                var original = context.Suppliers.SingleOrDefault(r => r.Id == supplier.Id);
                if (original != null)
                {
						original.Id = supplier.Id;
						original.Name = supplier.Name;
						original.Address = supplier.Address;
						original.Notes = supplier.Notes;
						context.SubmitChanges();
                }
            }
        }

        public void Delete(Guid id)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                Supplier supplier = context.Suppliers.SingleOrDefault(r => r.Id == id);
                context.Suppliers.DeleteOnSubmit(supplier);
                context.SubmitChanges();
            }
        }

	
    }
}
