namespace AjFirstExample.Gateways
{
	using System;
	using System.Runtime.Serialization;
	using System.ServiceModel;
	using System.Collections.ObjectModel;

	using AjFirstExample.Services;
	using AjFirstExample.Services.Contracts;

   public class CustomersServiceClient : ClientBase<ICustomersService>, ICustomersService
   {
		public void Add(Customer customer) {
			base.Channel.Add(customer);
		}

		public void Update(Customer customer) {
			base.Channel.Update(customer);
		}

		public void Delete(Guid id) {
			base.Channel.Delete(id);
		}

		public Customer[] GetCustomers() {
			return base.Channel.GetCustomers();
		}

		public Customer GetCustomer(Guid id) {
			return base.Channel.GetCustomer(id);
		}
	}
}
