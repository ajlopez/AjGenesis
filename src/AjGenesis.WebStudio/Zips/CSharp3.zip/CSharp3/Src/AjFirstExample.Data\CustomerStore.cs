namespace AjFirstExample.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AjFirstExample.Data;

    public class CustomerStore: ICustomerStore
    {
        
        public void Add(Customer customer)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                var entity = new Customer()
                {
					Id = customer.Id, 
					Name = customer.Name, 
					Address = customer.Address, 
					Notes = customer.Notes 
                };

                context.Customers.InsertOnSubmit(entity);
                context.SubmitChanges();
            }
        }

        public Customer[] GetCustomers()
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                var entities = context.Customers.OrderBy( entity => entity.Id);
                
                return entities.ToArray();
            }
        }

        public Customer GetCustomer(Guid id)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                Customer customer  = context.Customers.SingleOrDefault(r => r.Id == id);
                return customer;
            }
        }
		
        public void Update(Customer customer)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                var original = context.Customers.SingleOrDefault(r => r.Id == customer.Id);
                if (original != null)
                {
						original.Id = customer.Id;
						original.Name = customer.Name;
						original.Address = customer.Address;
						original.Notes = customer.Notes;
						context.SubmitChanges();
                }
            }
        }

        public void Delete(Guid id)
        {
            using (AjFirstExampleDataContext context = new AjFirstExampleDataContext())
            {
                Customer customer = context.Customers.SingleOrDefault(r => r.Id == id);
                context.Customers.DeleteOnSubmit(customer);
                context.SubmitChanges();
            }
        }

	
    }
}
