namespace AjFirstExample.Services
{
	using System;
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.Transactions;
	using System.Linq;
	using System.Data;
	using Contracts;

	public class LinqCustomersService : ICustomersService
	{
		AjFirstExample.Data.ICustomerStore store;

		public LinqCustomersService(AjFirstExample.Data.ICustomerStore store)
		{
			this.store = store;
		}

		public LinqCustomersService()
            : this(new AjFirstExample.Data.CustomerStore())
		{
		}

       public void Add(Customer customer)
		{
            using (TransactionScope scope = new TransactionScope())
            {
                AjFirstExample.Data.Customer dataentity = new AjFirstExample.Data.Customer()
                {
						Id = Guid.NewGuid() ,
						Name = customer.Name,
						Address = customer.Address,
						Notes = customer.Notes
                };
                this.store.Add(dataentity);
                scope.Complete();
            }
		}

       public void Update(Customer customer)
		{
            using (TransactionScope scope = new TransactionScope())
            {
                AjFirstExample.Data.Customer dataentity = new AjFirstExample.Data.Customer()
                {
						Id = customer.Id,
						Name = customer.Name,
						Address = customer.Address,
						Notes = customer.Notes
                };
                this.store.Update(dataentity);
                scope.Complete();
            }
		}

       public void Delete(Guid id)
		{
			throw new NotImplementedException();
		}

       public Customer[] GetCustomers()
		{
			AjFirstExample.Data.Customer[] customers = this.store.GetCustomers();

			List<Customer> customersModel = new List<Customer>();

          foreach (AjFirstExample.Data.Customer customer in customers)
          {                
				Customer result = new Customer()
				{
					Id = customer.Id,
					Name = customer.Name,
					Address = customer.Address,
					Notes = customer.Notes
				};

				customersModel.Add(result);
			}

			return customersModel.ToArray();
		}


       public Customer GetCustomer(Guid id) 
		{
			AjFirstExample.Data.Customer customer = store.GetCustomer(id);

			Customer entity = new Customer
			{
				Id = customer.Id,
				Name = customer.Name,
				Address = customer.Address,
				Notes = customer.Notes
			};

			return entity;
		}

   }
}

