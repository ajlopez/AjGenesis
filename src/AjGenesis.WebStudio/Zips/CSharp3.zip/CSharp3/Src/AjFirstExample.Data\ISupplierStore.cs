namespace AjFirstExample.Data
{
    using System;
    using System.Collections.Generic;

    public interface ISupplierStore
    {
		void Add(Supplier supplier);
		void Update(Supplier supplier);
		void Delete(Guid id);
		Supplier[] GetSuppliers();
		Supplier GetSupplier(Guid id);
    }
}
