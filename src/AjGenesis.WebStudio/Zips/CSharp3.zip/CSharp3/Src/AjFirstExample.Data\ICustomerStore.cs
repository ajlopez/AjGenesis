namespace AjFirstExample.Data
{
    using System;
    using System.Collections.Generic;

    public interface ICustomerStore
    {
		void Add(Customer customer);
		void Update(Customer customer);
		void Delete(Guid id);
		Customer[] GetCustomers();
		Customer GetCustomer(Guid id);
    }
}
