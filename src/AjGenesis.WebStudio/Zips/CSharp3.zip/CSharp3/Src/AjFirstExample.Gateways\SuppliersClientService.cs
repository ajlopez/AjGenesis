namespace AjFirstExample.Gateways
{
	using System;
	using System.Runtime.Serialization;
	using System.ServiceModel;
	using System.Collections.ObjectModel;

	using AjFirstExample.Services;
	using AjFirstExample.Services.Contracts;

   public class SuppliersServiceClient : ClientBase<ISuppliersService>, ISuppliersService
   {
		public void Add(Supplier supplier) {
			base.Channel.Add(supplier);
		}

		public void Update(Supplier supplier) {
			base.Channel.Update(supplier);
		}

		public void Delete(Guid id) {
			base.Channel.Delete(id);
		}

		public Supplier[] GetSuppliers() {
			return base.Channel.GetSuppliers();
		}

		public Supplier GetSupplier(Guid id) {
			return base.Channel.GetSupplier(id);
		}
	}
}
