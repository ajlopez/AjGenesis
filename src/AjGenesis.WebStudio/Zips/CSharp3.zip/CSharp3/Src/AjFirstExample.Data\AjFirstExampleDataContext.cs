

namespace AjFirstExample.Data
{
	using System.Data.Linq;
	using System.Data.Linq.Mapping;
	using System.Data;
	using System.Collections.Generic;
	using System.Reflection;
	using System.Linq;
	using System.Linq.Expressions;
	using System.ComponentModel;
	using System;
	
	
	[System.Data.Linq.Mapping.DatabaseAttribute(Name="AjFirstExampleNet3")]
	public partial class AjFirstExampleDataContext : System.Data.Linq.DataContext
	{
        public AjFirstExampleDataContext() : base(@"Data Source=.\SQLEXPRESS;Initial Catalog=AjFirstExampleNet3;Integrated Security=True")
        {
        }

		public Table<Customer> Customers;
		public Table<Supplier> Suppliers;
	}

	[Table(Name = "customers")]
	public class Customer
	{
        private Guid _id;
        private string _name;
        private string _address;
        private string _notes;

	
		[Column(Name="Id", Storage="_id", IsPrimaryKey=true)]
		public Guid Id
		{
			get { return _id; }
			set { _id = value; }
		}

		[Column(Name="Name", Storage="_name")]
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

		[Column(Name="Address", Storage="_address")]
		public string Address
		{
			get { return _address; }
			set { _address = value; }
		}

		[Column(Name="Notes", Storage="_notes")]
		public string Notes
		{
			get { return _notes; }
			set { _notes = value; }
		}

	}
	[Table(Name = "suppliers")]
	public class Supplier
	{
        private Guid _id;
        private string _name;
        private string _address;
        private string _notes;

	
		[Column(Name="Id", Storage="_id", IsPrimaryKey=true)]
		public Guid Id
		{
			get { return _id; }
			set { _id = value; }
		}

		[Column(Name="Name", Storage="_name")]
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

		[Column(Name="Address", Storage="_address")]
		public string Address
		{
			get { return _address; }
			set { _address = value; }
		}

		[Column(Name="Notes", Storage="_notes")]
		public string Notes
		{
			get { return _notes; }
			set { _notes = value; }
		}

	}

}

