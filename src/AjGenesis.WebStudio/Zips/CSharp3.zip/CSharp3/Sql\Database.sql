
--
--		Project:		AjFirstExample
--		Description:	First Example using AjGenesis
--

use master

declare @dttm varchar(55)
select  @dttm=convert(varchar,getdate(),113)
raiserror('Beginning Create AjFirstExampleNet3.SQL at %s ....',1,1,@dttm) with nowait

GO

if exists (select * from sysdatabases where name='AjFirstExampleNet3')
begin
  raiserror('Dropping existing AjFirstExampleNet3 database ....',0,1)
  DROP database AjFirstExampleNet3
end
GO

CHECKPOINT
go

raiserror('Creating AjFirstExampleNet3 database....',0,1)
go

/*
   Use default size with autogrow
*/

create database AjFirstExampleNet3
go

checkpoint

go

use AjFirstExampleNet3

go

if db_name() <> 'AjFirstExampleNet3'
   raiserror('Error in AjFirstExampleNet3.SQL, ''USE AjFirstExampleNet3'' failed!  Killing the SPID now.'
            ,22,127) with log

go

use AjFirstExampleNet3
go
set ansi_nulls on
go
set quoted_identifier on
go


--
--		Entity:		Customer
--		Description:	Customer Entity
--


if exists (select name from sysobjects 
         where name = 'customers' and type = 'U')
	drop table customers
go

create table customers (
		[Id] [int] identity (1, 1) primary key not null,	
		[Name] varchar(200),	
		[Address] text,	
		[Notes] text
)
go


if exists (select name from sysobjects 
         where name = 'CustomerInsert' and type = 'P')
	drop procedure dbo.CustomerInsert
go

create procedure dbo.CustomerInsert
	(
		@Id int output,	
		@Name varchar(200),	
		@Address text,	
		@Notes text
	)
as
	Insert into customers(	
		[Name],	
		[Address],	
		[Notes]
		)
	values (	
		@Name,	
		@Address,	
		@Notes		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'CustomerUpdate' and type = 'P')
	drop procedure dbo.CustomerUpdate
go

create procedure dbo.CustomerUpdate
	(
	
		@Id int,	
		@Name varchar(200),	
		@Address text,	
		@Notes text
	)
as
	Update customers
		set 	
			[Name] = @Name,	
			[Address] = @Address,	
			[Notes] = @Notes
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'CustomerDelete' and type = 'P')
	drop procedure dbo.CustomerDelete
go

create procedure dbo.CustomerDelete
	(
		@Id int
	)
as
	Delete customers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'CustomerGetById' and type = 'P')
	drop procedure dbo.CustomerGetById
go

create procedure dbo.CustomerGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Name],	
		[Address],	
		[Notes]
	from customers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'CustomerGetAll' and type = 'P')
	drop procedure dbo.CustomerGetAll
go

create procedure dbo.CustomerGetAll
as
	select 	
		[Id],	
		[Name],	
		[Address],	
		[Notes]
	from customers
	order by Id
go


--
--		Entity:		Supplier
--		Description:	Supplier Entity
--


if exists (select name from sysobjects 
         where name = 'suppliers' and type = 'U')
	drop table suppliers
go

create table suppliers (
		[Id] [int] identity (1, 1) primary key not null,	
		[Name] varchar(200),	
		[Address] text,	
		[Notes] text
)
go


if exists (select name from sysobjects 
         where name = 'SupplierInsert' and type = 'P')
	drop procedure dbo.SupplierInsert
go

create procedure dbo.SupplierInsert
	(
		@Id int output,	
		@Name varchar(200),	
		@Address text,	
		@Notes text
	)
as
	Insert into suppliers(	
		[Name],	
		[Address],	
		[Notes]
		)
	values (	
		@Name,	
		@Address,	
		@Notes		)
	set @Id = @@identity
	return
go


if exists (select name from sysobjects 
         where name = 'SupplierUpdate' and type = 'P')
	drop procedure dbo.SupplierUpdate
go

create procedure dbo.SupplierUpdate
	(
	
		@Id int,	
		@Name varchar(200),	
		@Address text,	
		@Notes text
	)
as
	Update suppliers
		set 	
			[Name] = @Name,	
			[Address] = @Address,	
			[Notes] = @Notes
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SupplierDelete' and type = 'P')
	drop procedure dbo.SupplierDelete
go

create procedure dbo.SupplierDelete
	(
		@Id int
	)
as
	Delete suppliers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SupplierGetById' and type = 'P')
	drop procedure dbo.SupplierGetById
go

create procedure dbo.SupplierGetById
	(
		@Id  int
	)
as
	select 	
		[Id],	
		[Name],	
		[Address],	
		[Notes]
	from suppliers
	where Id = @Id
go


if exists (select name from sysobjects 
         where name = 'SupplierGetAll' and type = 'P')
	drop procedure dbo.SupplierGetAll
go

create procedure dbo.SupplierGetAll
as
	select 	
		[Id],	
		[Name],	
		[Address],	
		[Notes]
	from suppliers
	order by Id
go

